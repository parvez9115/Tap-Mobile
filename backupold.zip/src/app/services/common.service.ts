import { Injectable } from '@angular/core';
import { LoadingController, ToastController } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';
import { ServerUrl } from 'src/environments/environment';
import { AjaxService } from './ajax.service';

@Injectable({
  providedIn: 'root'
})
export class CommonServices {
  public loginMenuInfo = new BehaviorSubject('');
  isLoading: boolean;
  constructor(
    private toastController: ToastController,
    private ajaxService: AjaxService,
    private loadingController: LoadingController,
  ) { }

  updateLoginInfo(item: any) {
    this.loginMenuInfo.next(item);
  }

  async presentLoader() {
    this.isLoading = true;

    setTimeout(() => {
      this.dismissLoader();
    }, 200000);

    return await this.loadingController.create({
      spinner: "circles",
      message: "Please Wait!",
      translucent: false,
      cssClass: 'custom-loader-class'
    }).then(a => {
      a.present().then(() => {
        console.log('presented');
        if (!this.isLoading) {
          a.dismiss().then(() => console.log('abort presenting'));
        }
      });
    });


  }
  
  async presentToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000
    });
    toast.present();
  }

  async dismissLoader() {
    this.isLoading = false;
    return await this.loadingController.dismiss().then(() => console.log('dismissed'));
  }

  async presentToastWithOk(msg) {
    let toast = await this.toastController.create({
      message: msg,
      // duration: 3000,
      position: 'bottom',
      buttons: [{
        text: 'Ok',
        role: 'cancel',
        handler: () => {
          toast.dismiss()
        }
      }
      ]
    });

    toast.present();
  }

  async networkChecker() {
    return navigator.onLine;
    //   // this.commonService.presentAlert("Error", "Please, check your internet connection")
    //   if(this.isLoading == true){
    //     this.dismissLoader();
    //   }
    //   const alert = await this.alertController.create({
    //    header: ' Connection Error',
    //    backdropDismiss: false,
    //    message: "Please check your internet connection",
    //    buttons: [
    //    {
    //      text: 'Connected',
    //      handler: data => {
    //       if(!navigator.onLine){
    //         this.networkChecker()
    //       }
    //      }
    //    }]
    //  });
    //  await alert.present();
  }
}
