(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common-form-common-form-module"], {
    /***/
    "./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js":
    /*!*******************************************************************************!*\
      !*** ./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js ***!
      \*******************************************************************************/

    /*! exports provided: FileDropDirective, FileItem, FileLikeObject, FileSelectDirective, FileUploadModule, FileUploader */

    /***/
    function node_modulesNg2FileUpload__ivy_ngcc__Fesm2015Ng2FileUploadJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileDropDirective", function () {
        return FileDropDirective;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileItem", function () {
        return FileItem;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileLikeObject", function () {
        return FileLikeObject;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileSelectDirective", function () {
        return FileSelectDirective;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileUploadModule", function () {
        return FileUploadModule;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FileUploader", function () {
        return FileUploader;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /**
       * @param {?} node
       * @return {?}
       */


      function isElement(node) {
        return !!(node && (node.nodeName || node.prop && node.attr && node.find));
      }

      var FileLikeObject = /*#__PURE__*/function () {
        /**
         * @param {?} fileOrInput
         */
        function FileLikeObject(fileOrInput) {
          _classCallCheck(this, FileLikeObject);

          this.rawFile = fileOrInput;
          /** @type {?} */

          var isInput = isElement(fileOrInput);
          /** @type {?} */

          var fakePathOrObject = isInput ? fileOrInput.value : fileOrInput;
          /** @type {?} */

          var postfix = typeof fakePathOrObject === 'string' ? 'FakePath' : 'Object';
          /** @type {?} */

          var method = '_createFrom' + postfix;

          /** @type {?} */
          this[method](fakePathOrObject);
        }
        /**
         * @param {?} path
         * @return {?}
         */


        _createClass(FileLikeObject, [{
          key: "_createFromFakePath",
          value: function _createFromFakePath(path) {
            this.lastModifiedDate = void 0;
            this.size = void 0;
            this.type = 'like/' + path.slice(path.lastIndexOf('.') + 1).toLowerCase();
            this.name = path.slice(path.lastIndexOf('/') + path.lastIndexOf('\\') + 2);
          }
          /**
           * @param {?} object
           * @return {?}
           */

        }, {
          key: "_createFromObject",
          value: function _createFromObject(object) {
            this.size = object.size;
            this.type = object.type;
            this.name = object.name;
          }
        }]);

        return FileLikeObject;
      }();

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var FileItem = /*#__PURE__*/function () {
        /**
         * @param {?} uploader
         * @param {?} some
         * @param {?} options
         */
        function FileItem(uploader, some, options) {
          _classCallCheck(this, FileItem);

          this.url = '/';
          this.headers = [];
          this.withCredentials = true;
          this.formData = [];
          this.isReady = false;
          this.isUploading = false;
          this.isUploaded = false;
          this.isSuccess = false;
          this.isCancel = false;
          this.isError = false;
          this.progress = 0;
          this.index = void 0;
          this.uploader = uploader;
          this.some = some;
          this.options = options;
          this.file = new FileLikeObject(some);
          this._file = some;

          if (uploader.options) {
            this.method = uploader.options.method || 'POST';
            this.alias = uploader.options.itemAlias || 'file';
          }

          this.url = uploader.options.url;
        }
        /**
         * @return {?}
         */


        _createClass(FileItem, [{
          key: "upload",
          value: function upload() {
            try {
              this.uploader.uploadItem(this);
            } catch (e) {
              this.uploader._onCompleteItem(this, '', 0, {});

              this.uploader._onErrorItem(this, '', 0, {});
            }
          }
          /**
           * @return {?}
           */

        }, {
          key: "cancel",
          value: function cancel() {
            this.uploader.cancelItem(this);
          }
          /**
           * @return {?}
           */

        }, {
          key: "remove",
          value: function remove() {
            this.uploader.removeFromQueue(this);
          }
          /**
           * @return {?}
           */

        }, {
          key: "onBeforeUpload",
          value: function onBeforeUpload() {
            return void 0;
          }
          /**
           * @param {?} form
           * @return {?}
           */

        }, {
          key: "onBuildForm",
          value: function onBuildForm(form) {
            return {
              form: form
            };
          }
          /**
           * @param {?} progress
           * @return {?}
           */

        }, {
          key: "onProgress",
          value: function onProgress(progress) {
            return {
              progress: progress
            };
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onSuccess",
          value: function onSuccess(response, status, headers) {
            return {
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onError",
          value: function onError(response, status, headers) {
            return {
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onCancel",
          value: function onCancel(response, status, headers) {
            return {
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onComplete",
          value: function onComplete(response, status, headers) {
            return {
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @return {?}
           */

        }, {
          key: "_onBeforeUpload",
          value: function _onBeforeUpload() {
            this.isReady = true;
            this.isUploading = true;
            this.isUploaded = false;
            this.isSuccess = false;
            this.isCancel = false;
            this.isError = false;
            this.progress = 0;
            this.onBeforeUpload();
          }
          /**
           * @param {?} form
           * @return {?}
           */

        }, {
          key: "_onBuildForm",
          value: function _onBuildForm(form) {
            this.onBuildForm(form);
          }
          /**
           * @param {?} progress
           * @return {?}
           */

        }, {
          key: "_onProgress",
          value: function _onProgress(progress) {
            this.progress = progress;
            this.onProgress(progress);
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onSuccess",
          value: function _onSuccess(response, status, headers) {
            this.isReady = false;
            this.isUploading = false;
            this.isUploaded = true;
            this.isSuccess = true;
            this.isCancel = false;
            this.isError = false;
            this.progress = 100;
            this.index = void 0;
            this.onSuccess(response, status, headers);
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onError",
          value: function _onError(response, status, headers) {
            this.isReady = false;
            this.isUploading = false;
            this.isUploaded = true;
            this.isSuccess = false;
            this.isCancel = false;
            this.isError = true;
            this.progress = 0;
            this.index = void 0;
            this.onError(response, status, headers);
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onCancel",
          value: function _onCancel(response, status, headers) {
            this.isReady = false;
            this.isUploading = false;
            this.isUploaded = false;
            this.isSuccess = false;
            this.isCancel = true;
            this.isError = false;
            this.progress = 0;
            this.index = void 0;
            this.onCancel(response, status, headers);
          }
          /**
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onComplete",
          value: function _onComplete(response, status, headers) {
            this.onComplete(response, status, headers);

            if (this.uploader.options.removeAfterUpload) {
              this.remove();
            }
          }
          /**
           * @return {?}
           */

        }, {
          key: "_prepareToUploading",
          value: function _prepareToUploading() {
            this.index = this.index || ++this.uploader._nextIndex;
            this.isReady = true;
          }
        }]);

        return FileItem;
      }();

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var FileType = /*#__PURE__*/function () {
        function FileType() {
          _classCallCheck(this, FileType);
        }

        _createClass(FileType, null, [{
          key: "getMimeClass",

          /**
           * @param {?} file
           * @return {?}
           */
          value: function getMimeClass(file) {
            /** @type {?} */
            var mimeClass = 'application';

            if (this.mime_psd.indexOf(file.type) !== -1) {
              mimeClass = 'image';
            } else if (file.type.match('image.*')) {
              mimeClass = 'image';
            } else if (file.type.match('video.*')) {
              mimeClass = 'video';
            } else if (file.type.match('audio.*')) {
              mimeClass = 'audio';
            } else if (file.type === 'application/pdf') {
              mimeClass = 'pdf';
            } else if (this.mime_compress.indexOf(file.type) !== -1) {
              mimeClass = 'compress';
            } else if (this.mime_doc.indexOf(file.type) !== -1) {
              mimeClass = 'doc';
            } else if (this.mime_xsl.indexOf(file.type) !== -1) {
              mimeClass = 'xls';
            } else if (this.mime_ppt.indexOf(file.type) !== -1) {
              mimeClass = 'ppt';
            }

            if (mimeClass === 'application') {
              mimeClass = this.fileTypeDetection(file.name);
            }

            return mimeClass;
          }
          /**
           * @param {?} inputFilename
           * @return {?}
           */

        }, {
          key: "fileTypeDetection",
          value: function fileTypeDetection(inputFilename) {
            /** @type {?} */
            var types = {
              'jpg': 'image',
              'jpeg': 'image',
              'tif': 'image',
              'psd': 'image',
              'bmp': 'image',
              'png': 'image',
              'nef': 'image',
              'tiff': 'image',
              'cr2': 'image',
              'dwg': 'image',
              'cdr': 'image',
              'ai': 'image',
              'indd': 'image',
              'pin': 'image',
              'cdp': 'image',
              'skp': 'image',
              'stp': 'image',
              '3dm': 'image',
              'mp3': 'audio',
              'wav': 'audio',
              'wma': 'audio',
              'mod': 'audio',
              'm4a': 'audio',
              'compress': 'compress',
              'zip': 'compress',
              'rar': 'compress',
              '7z': 'compress',
              'lz': 'compress',
              'z01': 'compress',
              'bz2': 'compress',
              'gz': 'compress',
              'pdf': 'pdf',
              'xls': 'xls',
              'xlsx': 'xls',
              'ods': 'xls',
              'mp4': 'video',
              'avi': 'video',
              'wmv': 'video',
              'mpg': 'video',
              'mts': 'video',
              'flv': 'video',
              '3gp': 'video',
              'vob': 'video',
              'm4v': 'video',
              'mpeg': 'video',
              'm2ts': 'video',
              'mov': 'video',
              'doc': 'doc',
              'docx': 'doc',
              'eps': 'doc',
              'txt': 'doc',
              'odt': 'doc',
              'rtf': 'doc',
              'ppt': 'ppt',
              'pptx': 'ppt',
              'pps': 'ppt',
              'ppsx': 'ppt',
              'odp': 'ppt'
            };
            /** @type {?} */

            var chunks = inputFilename.split('.');

            if (chunks.length < 2) {
              return 'application';
            }
            /** @type {?} */


            var extension = chunks[chunks.length - 1].toLowerCase();

            if (types[extension] === undefined) {
              return 'application';
            } else {
              return types[extension];
            }
          }
        }]);

        return FileType;
      }();
      /*  MS office  */


      FileType.mime_doc = ['application/msword', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.wordprocessingml.template', 'application/vnd.ms-word.document.macroEnabled.12', 'application/vnd.ms-word.template.macroEnabled.12'];
      FileType.mime_xsl = ['application/vnd.ms-excel', 'application/vnd.ms-excel', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.template', 'application/vnd.ms-excel.sheet.macroEnabled.12', 'application/vnd.ms-excel.template.macroEnabled.12', 'application/vnd.ms-excel.addin.macroEnabled.12', 'application/vnd.ms-excel.sheet.binary.macroEnabled.12'];
      FileType.mime_ppt = ['application/vnd.ms-powerpoint', 'application/vnd.ms-powerpoint', 'application/vnd.ms-powerpoint', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.openxmlformats-officedocument.presentationml.template', 'application/vnd.openxmlformats-officedocument.presentationml.slideshow', 'application/vnd.ms-powerpoint.addin.macroEnabled.12', 'application/vnd.ms-powerpoint.presentation.macroEnabled.12', 'application/vnd.ms-powerpoint.presentation.macroEnabled.12', 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12'];
      /* PSD */

      FileType.mime_psd = ['image/photoshop', 'image/x-photoshop', 'image/psd', 'application/photoshop', 'application/psd', 'zz-application/zz-winassoc-psd'];
      /* Compressed files */

      FileType.mime_compress = ['application/x-gtar', 'application/x-gcompress', 'application/compress', 'application/x-tar', 'application/x-rar-compressed', 'application/octet-stream', 'application/x-zip-compressed', 'application/zip-compressed', 'application/x-7z-compressed', 'application/gzip', 'application/x-bzip2'];

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /**
       * @param {?} value
       * @return {?}
       */


      function _isFile(value) {
        return File && value instanceof File;
      }
      /**
       * @record
       */


      function Headers() {}

      if (false) {}
      /**
       * @record
       */


      function FileUploaderOptions() {}

      if (false) {}

      var FileUploader = /*#__PURE__*/function () {
        /**
         * @param {?} options
         */
        function FileUploader(options) {
          _classCallCheck(this, FileUploader);

          this.isUploading = false;
          this.queue = [];
          this.progress = 0;
          this._nextIndex = 0;
          this.options = {
            autoUpload: false,
            isHTML5: true,
            filters: [],
            removeAfterUpload: false,
            disableMultipart: false,
            formatDataFunction:
            /**
            * @param {?} item
            * @return {?}
            */
            function formatDataFunction(item) {
              return item._file;
            },
            formatDataFunctionIsAsync: false
          };
          this.setOptions(options);
          this.response = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        }
        /**
         * @param {?} options
         * @return {?}
         */


        _createClass(FileUploader, [{
          key: "setOptions",
          value: function setOptions(options) {
            this.options = Object.assign(this.options, options);
            this.authToken = this.options.authToken;
            this.authTokenHeader = this.options.authTokenHeader || 'Authorization';
            this.autoUpload = this.options.autoUpload;
            this.options.filters.unshift({
              name: 'queueLimit',
              fn: this._queueLimitFilter
            });

            if (this.options.maxFileSize) {
              this.options.filters.unshift({
                name: 'fileSize',
                fn: this._fileSizeFilter
              });
            }

            if (this.options.allowedFileType) {
              this.options.filters.unshift({
                name: 'fileType',
                fn: this._fileTypeFilter
              });
            }

            if (this.options.allowedMimeType) {
              this.options.filters.unshift({
                name: 'mimeType',
                fn: this._mimeTypeFilter
              });
            }

            for (var i = 0; i < this.queue.length; i++) {
              this.queue[i].url = this.options.url;
            }
          }
          /**
           * @param {?} files
           * @param {?=} options
           * @param {?=} filters
           * @return {?}
           */

        }, {
          key: "addToQueue",
          value: function addToQueue(files, options, filters) {
            var _this = this;

            /** @type {?} */
            var list = [];

            var _iterator = _createForOfIteratorHelper(files),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var file = _step.value;
                list.push(file);
              }
              /** @type {?} */

            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            var arrayOfFilters = this._getFilters(filters);
            /** @type {?} */


            var count = this.queue.length;
            /** @type {?} */

            var addedFileItems = [];
            list.map(
            /**
            * @param {?} some
            * @return {?}
            */
            function (some) {
              if (!options) {
                options = _this.options;
              }
              /** @type {?} */


              var temp = new FileLikeObject(some);

              if (_this._isValidFile(temp, arrayOfFilters, options)) {
                /** @type {?} */
                var fileItem = new FileItem(_this, some, options);
                addedFileItems.push(fileItem);

                _this.queue.push(fileItem);

                _this._onAfterAddingFile(fileItem);
              } else {
                /** @type {?} */
                var filter = arrayOfFilters[_this._failFilterIndex];

                _this._onWhenAddingFileFailed(temp, filter, options);
              }
            });

            if (this.queue.length !== count) {
              this._onAfterAddingAll(addedFileItems);

              this.progress = this._getTotalProgress();
            }

            this._render();

            if (this.options.autoUpload) {
              this.uploadAll();
            }
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "removeFromQueue",
          value: function removeFromQueue(value) {
            /** @type {?} */
            var index = this.getIndexOfItem(value);
            /** @type {?} */

            var item = this.queue[index];

            if (item.isUploading) {
              item.cancel();
            }

            this.queue.splice(index, 1);
            this.progress = this._getTotalProgress();
          }
          /**
           * @return {?}
           */

        }, {
          key: "clearQueue",
          value: function clearQueue() {
            while (this.queue.length) {
              this.queue[0].remove();
            }

            this.progress = 0;
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "uploadItem",
          value: function uploadItem(value) {
            /** @type {?} */
            var index = this.getIndexOfItem(value);
            /** @type {?} */

            var item = this.queue[index];
            /** @type {?} */

            var transport = this.options.isHTML5 ? '_xhrTransport' : '_iframeTransport';

            item._prepareToUploading();

            if (this.isUploading) {
              return;
            }

            this.isUploading = true;

            /** @type {?} */
            this[transport](item);
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "cancelItem",
          value: function cancelItem(value) {
            /** @type {?} */
            var index = this.getIndexOfItem(value);
            /** @type {?} */

            var item = this.queue[index];
            /** @type {?} */

            var prop = this.options.isHTML5 ? item._xhr : item._form;

            if (item && item.isUploading) {
              prop.abort();
            }
          }
          /**
           * @return {?}
           */

        }, {
          key: "uploadAll",
          value: function uploadAll() {
            /** @type {?} */
            var items = this.getNotUploadedItems().filter(
            /**
            * @param {?} item
            * @return {?}
            */
            function (item) {
              return !item.isUploading;
            });

            if (!items.length) {
              return;
            }

            items.map(
            /**
            * @param {?} item
            * @return {?}
            */
            function (item) {
              return item._prepareToUploading();
            });
            items[0].upload();
          }
          /**
           * @return {?}
           */

        }, {
          key: "cancelAll",
          value: function cancelAll() {
            /** @type {?} */
            var items = this.getNotUploadedItems();
            items.map(
            /**
            * @param {?} item
            * @return {?}
            */
            function (item) {
              return item.cancel();
            });
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "isFile",
          value: function isFile(value) {
            return _isFile(value);
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "isFileLikeObject",
          value: function isFileLikeObject(value) {
            return value instanceof FileLikeObject;
          }
          /**
           * @param {?} value
           * @return {?}
           */

        }, {
          key: "getIndexOfItem",
          value: function getIndexOfItem(value) {
            return typeof value === 'number' ? value : this.queue.indexOf(value);
          }
          /**
           * @return {?}
           */

        }, {
          key: "getNotUploadedItems",
          value: function getNotUploadedItems() {
            return this.queue.filter(
            /**
            * @param {?} item
            * @return {?}
            */
            function (item) {
              return !item.isUploaded;
            });
          }
          /**
           * @return {?}
           */

        }, {
          key: "getReadyItems",
          value: function getReadyItems() {
            return this.queue.filter(
            /**
            * @param {?} item
            * @return {?}
            */
            function (item) {
              return item.isReady && !item.isUploading;
            }).sort(
            /**
            * @param {?} item1
            * @param {?} item2
            * @return {?}
            */
            function (item1, item2) {
              return item1.index - item2.index;
            });
          }
          /**
           * @return {?}
           */

        }, {
          key: "destroy",
          value: function destroy() {
            return void 0;
          }
          /**
           * @param {?} fileItems
           * @return {?}
           */

        }, {
          key: "onAfterAddingAll",
          value: function onAfterAddingAll(fileItems) {
            return {
              fileItems: fileItems
            };
          }
          /**
           * @param {?} fileItem
           * @param {?} form
           * @return {?}
           */

        }, {
          key: "onBuildItemForm",
          value: function onBuildItemForm(fileItem, form) {
            return {
              fileItem: fileItem,
              form: form
            };
          }
          /**
           * @param {?} fileItem
           * @return {?}
           */

        }, {
          key: "onAfterAddingFile",
          value: function onAfterAddingFile(fileItem) {
            return {
              fileItem: fileItem
            };
          }
          /**
           * @param {?} item
           * @param {?} filter
           * @param {?} options
           * @return {?}
           */

        }, {
          key: "onWhenAddingFileFailed",
          value: function onWhenAddingFileFailed(item, filter, options) {
            return {
              item: item,
              filter: filter,
              options: options
            };
          }
          /**
           * @param {?} fileItem
           * @return {?}
           */

        }, {
          key: "onBeforeUploadItem",
          value: function onBeforeUploadItem(fileItem) {
            return {
              fileItem: fileItem
            };
          }
          /**
           * @param {?} fileItem
           * @param {?} progress
           * @return {?}
           */

        }, {
          key: "onProgressItem",
          value: function onProgressItem(fileItem, progress) {
            return {
              fileItem: fileItem,
              progress: progress
            };
          }
          /**
           * @param {?} progress
           * @return {?}
           */

        }, {
          key: "onProgressAll",
          value: function onProgressAll(progress) {
            return {
              progress: progress
            };
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onSuccessItem",
          value: function onSuccessItem(item, response, status, headers) {
            return {
              item: item,
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onErrorItem",
          value: function onErrorItem(item, response, status, headers) {
            return {
              item: item,
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onCancelItem",
          value: function onCancelItem(item, response, status, headers) {
            return {
              item: item,
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "onCompleteItem",
          value: function onCompleteItem(item, response, status, headers) {
            return {
              item: item,
              response: response,
              status: status,
              headers: headers
            };
          }
          /**
           * @return {?}
           */

        }, {
          key: "onCompleteAll",
          value: function onCompleteAll() {
            return void 0;
          }
          /**
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_mimeTypeFilter",
          value: function _mimeTypeFilter(item) {
            return !(this.options.allowedMimeType && this.options.allowedMimeType.indexOf(item.type) === -1);
          }
          /**
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_fileSizeFilter",
          value: function _fileSizeFilter(item) {
            return !(this.options.maxFileSize && item.size > this.options.maxFileSize);
          }
          /**
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_fileTypeFilter",
          value: function _fileTypeFilter(item) {
            return !(this.options.allowedFileType && this.options.allowedFileType.indexOf(FileType.getMimeClass(item)) === -1);
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onErrorItem",
          value: function _onErrorItem(item, response, status, headers) {
            item._onError(response, status, headers);

            this.onErrorItem(item, response, status, headers);
          }
          /**
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onCompleteItem",
          value: function _onCompleteItem(item, response, status, headers) {
            item._onComplete(response, status, headers);

            this.onCompleteItem(item, response, status, headers);
            /** @type {?} */

            var nextItem = this.getReadyItems()[0];
            this.isUploading = false;

            if (nextItem) {
              nextItem.upload();
              return;
            }

            this.onCompleteAll();
            this.progress = this._getTotalProgress();

            this._render();
          }
          /**
           * @protected
           * @param {?} parsedHeaders
           * @return {?}
           */

        }, {
          key: "_headersGetter",
          value: function _headersGetter(parsedHeaders) {
            return (
              /**
              * @param {?} name
              * @return {?}
              */
              function (name) {
                if (name) {
                  return parsedHeaders[name.toLowerCase()] || void 0;
                }

                return parsedHeaders;
              }
            );
          }
          /**
           * @protected
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_xhrTransport",
          value: function _xhrTransport(item) {
            var _this2 = this;

            /** @type {?} */
            var that = this;
            /** @type {?} */

            var xhr = item._xhr = new XMLHttpRequest();
            /** @type {?} */

            var sendable;

            this._onBeforeUploadItem(item);

            if (typeof item._file.size !== 'number') {
              throw new TypeError('The file specified is no longer valid');
            }

            if (!this.options.disableMultipart) {
              sendable = new FormData();

              this._onBuildItemForm(item, sendable);
              /** @type {?} */


              var appendFile =
              /**
              * @return {?}
              */
              function appendFile() {
                return sendable.append(item.alias, item._file, item.file.name);
              };

              if (!this.options.parametersBeforeFiles) {
                appendFile();
              } // For AWS, Additional Parameters must come BEFORE Files


              if (this.options.additionalParameter !== undefined) {
                Object.keys(this.options.additionalParameter).forEach(
                /**
                * @param {?} key
                * @return {?}
                */
                function (key) {
                  /** @type {?} */
                  var paramVal = _this2.options.additionalParameter[key]; // Allow an additional parameter to include the filename

                  if (typeof paramVal === 'string' && paramVal.indexOf('{{file_name}}') >= 0) {
                    paramVal = paramVal.replace('{{file_name}}', item.file.name);
                  }

                  sendable.append(key, paramVal);
                });
              }

              if (this.options.parametersBeforeFiles) {
                appendFile();
              }
            } else {
              sendable = this.options.formatDataFunction(item);
            }

            xhr.upload.onprogress =
            /**
            * @param {?} event
            * @return {?}
            */
            function (event) {
              /** @type {?} */
              var progress = Math.round(event.lengthComputable ? event.loaded * 100 / event.total : 0);

              _this2._onProgressItem(item, progress);
            };

            xhr.onload =
            /**
            * @return {?}
            */
            function () {
              /** @type {?} */
              var headers = _this2._parseHeaders(xhr.getAllResponseHeaders());
              /** @type {?} */


              var response = _this2._transformResponse(xhr.response, headers);
              /** @type {?} */


              var gist = _this2._isSuccessCode(xhr.status) ? 'Success' : 'Error';
              /** @type {?} */

              var method = '_on' + gist + 'Item';

              /** @type {?} */
              _this2[method](item, response, xhr.status, headers);

              _this2._onCompleteItem(item, response, xhr.status, headers);
            };

            xhr.onerror =
            /**
            * @return {?}
            */
            function () {
              /** @type {?} */
              var headers = _this2._parseHeaders(xhr.getAllResponseHeaders());
              /** @type {?} */


              var response = _this2._transformResponse(xhr.response, headers);

              _this2._onErrorItem(item, response, xhr.status, headers);

              _this2._onCompleteItem(item, response, xhr.status, headers);
            };

            xhr.onabort =
            /**
            * @return {?}
            */
            function () {
              /** @type {?} */
              var headers = _this2._parseHeaders(xhr.getAllResponseHeaders());
              /** @type {?} */


              var response = _this2._transformResponse(xhr.response, headers);

              _this2._onCancelItem(item, response, xhr.status, headers);

              _this2._onCompleteItem(item, response, xhr.status, headers);
            };

            xhr.open(item.method, item.url, true);
            xhr.withCredentials = item.withCredentials;

            if (this.options.headers) {
              var _iterator2 = _createForOfIteratorHelper(this.options.headers),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var header = _step2.value;
                  xhr.setRequestHeader(header.name, header.value);
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }

            if (item.headers.length) {
              var _iterator3 = _createForOfIteratorHelper(item.headers),
                  _step3;

              try {
                for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                  var _header = _step3.value;
                  xhr.setRequestHeader(_header.name, _header.value);
                }
              } catch (err) {
                _iterator3.e(err);
              } finally {
                _iterator3.f();
              }
            }

            if (this.authToken) {
              xhr.setRequestHeader(this.authTokenHeader, this.authToken);
            }

            xhr.onreadystatechange =
            /**
            * @return {?}
            */
            function () {
              if (xhr.readyState == XMLHttpRequest.DONE) {
                that.response.emit(xhr.responseText);
              }
            };

            if (this.options.formatDataFunctionIsAsync) {
              sendable.then(
              /**
              * @param {?} result
              * @return {?}
              */
              function (result) {
                return xhr.send(JSON.stringify(result));
              });
            } else {
              xhr.send(sendable);
            }

            this._render();
          }
          /**
           * @protected
           * @param {?=} value
           * @return {?}
           */

        }, {
          key: "_getTotalProgress",
          value: function _getTotalProgress() {
            var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

            if (this.options.removeAfterUpload) {
              return value;
            }
            /** @type {?} */


            var notUploaded = this.getNotUploadedItems().length;
            /** @type {?} */

            var uploaded = notUploaded ? this.queue.length - notUploaded : this.queue.length;
            /** @type {?} */

            var ratio = 100 / this.queue.length;
            /** @type {?} */

            var current = value * ratio / 100;
            return Math.round(uploaded * ratio + current);
          }
          /**
           * @protected
           * @param {?} filters
           * @return {?}
           */

        }, {
          key: "_getFilters",
          value: function _getFilters(filters) {
            if (!filters) {
              return this.options.filters;
            }

            if (Array.isArray(filters)) {
              return filters;
            }

            if (typeof filters === 'string') {
              /** @type {?} */
              var names = filters.match(/[^\s,]+/g);
              return this.options.filters.filter(
              /**
              * @param {?} filter
              * @return {?}
              */
              function (filter) {
                return names.indexOf(filter.name) !== -1;
              });
            }

            return this.options.filters;
          }
          /**
           * @protected
           * @return {?}
           */

        }, {
          key: "_render",
          value: function _render() {
            return void 0;
          }
          /**
           * @protected
           * @return {?}
           */

        }, {
          key: "_queueLimitFilter",
          value: function _queueLimitFilter() {
            return this.options.queueLimit === undefined || this.queue.length < this.options.queueLimit;
          }
          /**
           * @protected
           * @param {?} file
           * @param {?} filters
           * @param {?} options
           * @return {?}
           */

        }, {
          key: "_isValidFile",
          value: function _isValidFile(file, filters, options) {
            var _this3 = this;

            this._failFilterIndex = -1;
            return !filters.length ? true : filters.every(
            /**
            * @param {?} filter
            * @return {?}
            */
            function (filter) {
              _this3._failFilterIndex++;
              return filter.fn.call(_this3, file, options);
            });
          }
          /**
           * @protected
           * @param {?} status
           * @return {?}
           */

        }, {
          key: "_isSuccessCode",
          value: function _isSuccessCode(status) {
            return status >= 200 && status < 300 || status === 304;
          }
          /**
           * @protected
           * @param {?} response
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_transformResponse",
          value: function _transformResponse(response, headers) {
            return response;
          }
          /**
           * @protected
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_parseHeaders",
          value: function _parseHeaders(headers) {
            /** @type {?} */
            var parsed = {};
            /** @type {?} */

            var key;
            /** @type {?} */

            var val;
            /** @type {?} */

            var i;

            if (!headers) {
              return parsed;
            }

            headers.split('\n').map(
            /**
            * @param {?} line
            * @return {?}
            */
            function (line) {
              i = line.indexOf(':');
              key = line.slice(0, i).trim().toLowerCase();
              val = line.slice(i + 1).trim();

              if (key) {
                parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
              }
            });
            return parsed;
          }
          /**
           * @protected
           * @param {?} item
           * @param {?} filter
           * @param {?} options
           * @return {?}
           */

        }, {
          key: "_onWhenAddingFileFailed",
          value: function _onWhenAddingFileFailed(item, filter, options) {
            this.onWhenAddingFileFailed(item, filter, options);
          }
          /**
           * @protected
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_onAfterAddingFile",
          value: function _onAfterAddingFile(item) {
            this.onAfterAddingFile(item);
          }
          /**
           * @protected
           * @param {?} items
           * @return {?}
           */

        }, {
          key: "_onAfterAddingAll",
          value: function _onAfterAddingAll(items) {
            this.onAfterAddingAll(items);
          }
          /**
           * @protected
           * @param {?} item
           * @return {?}
           */

        }, {
          key: "_onBeforeUploadItem",
          value: function _onBeforeUploadItem(item) {
            item._onBeforeUpload();

            this.onBeforeUploadItem(item);
          }
          /**
           * @protected
           * @param {?} item
           * @param {?} form
           * @return {?}
           */

        }, {
          key: "_onBuildItemForm",
          value: function _onBuildItemForm(item, form) {
            item._onBuildForm(form);

            this.onBuildItemForm(item, form);
          }
          /**
           * @protected
           * @param {?} item
           * @param {?} progress
           * @return {?}
           */

        }, {
          key: "_onProgressItem",
          value: function _onProgressItem(item, progress) {
            /** @type {?} */
            var total = this._getTotalProgress(progress);

            this.progress = total;

            item._onProgress(progress);

            this.onProgressItem(item, progress);
            this.onProgressAll(total);

            this._render();
          }
          /**
           * @protected
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onSuccessItem",
          value: function _onSuccessItem(item, response, status, headers) {
            item._onSuccess(response, status, headers);

            this.onSuccessItem(item, response, status, headers);
          }
          /**
           * @protected
           * @param {?} item
           * @param {?} response
           * @param {?} status
           * @param {?} headers
           * @return {?}
           */

        }, {
          key: "_onCancelItem",
          value: function _onCancelItem(item, response, status, headers) {
            item._onCancel(response, status, headers);

            this.onCancelItem(item, response, status, headers);
          }
        }]);

        return FileUploader;
      }();

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var FileSelectDirective = /*#__PURE__*/function () {
        /**
         * @param {?} element
         */
        function FileSelectDirective(element) {
          _classCallCheck(this, FileSelectDirective);

          this.onFileSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
          this.element = element;
        }
        /**
         * @return {?}
         */


        _createClass(FileSelectDirective, [{
          key: "getOptions",
          value: function getOptions() {
            return this.uploader.options;
          }
          /**
           * @return {?}
           */

        }, {
          key: "getFilters",
          value: function getFilters() {
            return {};
          }
          /**
           * @return {?}
           */

        }, {
          key: "isEmptyAfterSelection",
          value: function isEmptyAfterSelection() {
            return !!this.element.nativeElement.attributes.multiple;
          }
          /**
           * @return {?}
           */

        }, {
          key: "onChange",
          value: function onChange() {
            /** @type {?} */
            var files = this.element.nativeElement.files;
            /** @type {?} */

            var options = this.getOptions();
            /** @type {?} */

            var filters = this.getFilters();
            this.uploader.addToQueue(files, options, filters);
            this.onFileSelected.emit(files);

            if (this.isEmptyAfterSelection()) {
              this.element.nativeElement.value = '';
            }
          }
        }]);

        return FileSelectDirective;
      }();

      FileSelectDirective.ɵfac = function FileSelectDirective_Factory(t) {
        return new (t || FileSelectDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]));
      };

      FileSelectDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
        type: FileSelectDirective,
        selectors: [["", "ng2FileSelect", ""]],
        hostBindings: function FileSelectDirective_HostBindings(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function FileSelectDirective_change_HostBindingHandler() {
              return ctx.onChange();
            });
          }
        },
        inputs: {
          uploader: "uploader"
        },
        outputs: {
          onFileSelected: "onFileSelected"
        }
      });
      /** @nocollapse */

      FileSelectDirective.ctorParameters = function () {
        return [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
        }];
      };

      FileSelectDirective.propDecorators = {
        uploader: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        onFileSelected: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }],
        onChange: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
          args: ['change']
        }]
      };
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FileSelectDirective, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
          args: [{
            selector: '[ng2FileSelect]'
          }]
        }], function () {
          return [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
          }];
        }, {
          onFileSelected: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
          }],

          /**
           * @return {?}
           */
          onChange: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['change']
          }],
          uploader: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }]
        });
      })();

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var FileDropDirective = /*#__PURE__*/function () {
        /**
         * @param {?} element
         */
        function FileDropDirective(element) {
          _classCallCheck(this, FileDropDirective);

          this.fileOver = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
          this.onFileDrop = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
          this.element = element;
        }
        /**
         * @return {?}
         */


        _createClass(FileDropDirective, [{
          key: "getOptions",
          value: function getOptions() {
            return this.uploader.options;
          }
          /**
           * @return {?}
           */

        }, {
          key: "getFilters",
          value: function getFilters() {
            return {};
          }
          /**
           * @param {?} event
           * @return {?}
           */

        }, {
          key: "onDrop",
          value: function onDrop(event) {
            /** @type {?} */
            var transfer = this._getTransfer(event);

            if (!transfer) {
              return;
            }
            /** @type {?} */


            var options = this.getOptions();
            /** @type {?} */

            var filters = this.getFilters();

            this._preventAndStop(event);

            this.uploader.addToQueue(transfer.files, options, filters);
            this.fileOver.emit(false);
            this.onFileDrop.emit(transfer.files);
          }
          /**
           * @param {?} event
           * @return {?}
           */

        }, {
          key: "onDragOver",
          value: function onDragOver(event) {
            /** @type {?} */
            var transfer = this._getTransfer(event);

            if (!this._haveFiles(transfer.types)) {
              return;
            }

            transfer.dropEffect = 'copy';

            this._preventAndStop(event);

            this.fileOver.emit(true);
          }
          /**
           * @param {?} event
           * @return {?}
           */

        }, {
          key: "onDragLeave",
          value: function onDragLeave(event) {
            if (
            /** @type {?} */
            this.element) {
              if (event.currentTarget ===
              /** @type {?} */
              this.element[0]) {
                return;
              }
            }

            this._preventAndStop(event);

            this.fileOver.emit(false);
          }
          /**
           * @protected
           * @param {?} event
           * @return {?}
           */

        }, {
          key: "_getTransfer",
          value: function _getTransfer(event) {
            return event.dataTransfer ? event.dataTransfer : event.originalEvent.dataTransfer; // jQuery fix;
          }
          /**
           * @protected
           * @param {?} event
           * @return {?}
           */

        }, {
          key: "_preventAndStop",
          value: function _preventAndStop(event) {
            event.preventDefault();
            event.stopPropagation();
          }
          /**
           * @protected
           * @param {?} types
           * @return {?}
           */

        }, {
          key: "_haveFiles",
          value: function _haveFiles(types) {
            if (!types) {
              return false;
            }

            if (types.indexOf) {
              return types.indexOf('Files') !== -1;
            } else if (types.contains) {
              return types.contains('Files');
            } else {
              return false;
            }
          }
        }]);

        return FileDropDirective;
      }();

      FileDropDirective.ɵfac = function FileDropDirective_Factory(t) {
        return new (t || FileDropDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]));
      };

      FileDropDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
        type: FileDropDirective,
        selectors: [["", "ng2FileDrop", ""]],
        hostBindings: function FileDropDirective_HostBindings(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("drop", function FileDropDirective_drop_HostBindingHandler($event) {
              return ctx.onDrop($event);
            })("dragover", function FileDropDirective_dragover_HostBindingHandler($event) {
              return ctx.onDragOver($event);
            })("dragleave", function FileDropDirective_dragleave_HostBindingHandler($event) {
              return ctx.onDragLeave($event);
            });
          }
        },
        inputs: {
          uploader: "uploader"
        },
        outputs: {
          fileOver: "fileOver",
          onFileDrop: "onFileDrop"
        }
      });
      /** @nocollapse */

      FileDropDirective.ctorParameters = function () {
        return [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
        }];
      };

      FileDropDirective.propDecorators = {
        uploader: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        fileOver: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }],
        onFileDrop: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }],
        onDrop: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
          args: ['drop', ['$event']]
        }],
        onDragOver: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
          args: ['dragover', ['$event']]
        }],
        onDragLeave: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
          args: ['dragleave', ['$event']]
        }]
      };
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FileDropDirective, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
          args: [{
            selector: '[ng2FileDrop]'
          }]
        }], function () {
          return [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
          }];
        }, {
          fileOver: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
          }],
          onFileDrop: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
          }],

          /**
           * @param {?} event
           * @return {?}
           */
          onDrop: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['drop', ['$event']]
          }],

          /**
           * @param {?} event
           * @return {?}
           */
          onDragOver: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['dragover', ['$event']]
          }],

          /**
           * @param {?} event
           * @return {?}
           */
          onDragLeave: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['dragleave', ['$event']]
          }],
          uploader: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }]
        });
      })();

      if (false) {}
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var FileUploadModule = function FileUploadModule() {
        _classCallCheck(this, FileUploadModule);
      };

      FileUploadModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: FileUploadModule
      });
      FileUploadModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function FileUploadModule_Factory(t) {
          return new (t || FileUploadModule)();
        },
        imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](FileUploadModule, {
          declarations: function declarations() {
            return [FileDropDirective, FileSelectDirective];
          },
          imports: function imports() {
            return [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]];
          },
          exports: function exports() {
            return [FileDropDirective, FileSelectDirective];
          }
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FileUploadModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
            declarations: [FileDropDirective, FileSelectDirective],
            exports: [FileDropDirective, FileSelectDirective]
          }]
        }], null, null);
      })();
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */
      //# sourceMappingURL=ng2-file-upload.js.map

      /***/

    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/common-form/common-form.page.html":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/common-form/common-form.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppCommonFormCommonFormPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n\n  <ion-card class=\"topBorder\" style=\"height: 96%;overflow: scroll;\">\n    <ion-card-content style=\"padding: 0px;\">\n      <ion-row class=\"headingClass\">\n        <ion-label>{{creation}}</ion-label>\n      </ion-row>\n      <form [formGroup]=\"profileForm\">\n        <ion-row *ngIf=\"formVisible.includes('rtoZone')\">\n          <ion-col class='headerSize'>RTO Details</ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col *ngIf=\"formVisible.includes('rtoZone')\" size='12' size-md=\"6\" size-lg=\"3\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item>\n\n              <ion-label> Select RTO </ion-label>\n              <input style=\"width: 100%;\n              height: 47px;\n              border: 0px;\" list=\"rto\" formControlName=\"rtoZone\" placeholder='Select rto zone'\n                style=\"padding: 0px; \" />\n\n              <datalist id=\"rto\">\n                <option *ngFor=\"let rto of rtoAreaCode\">{{rto}}</option>\n              </datalist>\n              <!-- <ion-select formControlName=\"rtoZone\">\n                <ion-select-option *ngFor=\"let rto of rtoAreaCode\" placeholder=\"select\">{{rto}} </ion-select-option>\n              </ion-select> -->\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.rtoZone.invalid\">\n              <div *ngIf=\"profileForm.controls.rtoZone.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('roleName')\" size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item>\n              <ion-label> Select Role </ion-label>\n              <ion-select formControlName=\"roleName\">\n                <ion-select-option *ngFor=\"let role of role\" placeholder=\"select\">{{role}}</ion-select-option>\n              </ion-select>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.roleName.invalid\">\n              <div *ngIf=\"profileForm.controls.roleName.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"formVisible.includes('name')\">\n          <ion-col class='headerSize'>Customer Information</ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col *ngIf=\"formVisible.includes('name')\" size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"person\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Name\" formControlName=\"name\"></ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.name.invalid\">\n              <div *ngIf=\"profileForm.controls.name.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('password')\" size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n              <ion-input [type]=\"password_type \" placeholder=\"Password\" formControlName=\"password\"></ion-input>\n              <ion-icon (click)=\"showHidePass()\" slot=\"end\" [name]=\"eye_icon\"></ion-icon>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.password.invalid\">\n              <div *ngIf=\"profileForm.controls.password.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('email')\" size='12'>\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"E-mail\" formControlName=\"email\"></ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.email.invalid\">\n              <div *ngIf=\"profileForm.controls.email\">\n                This Field is Required, Enter correct Mail Id.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('mobile1')\" size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Contact No 1\" maxlength=\"10\" type=\"tel\" formControlName=\"mobile1\">\n              </ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.mobile1.invalid\" class=\"alert alert-danger\">\n              <div *ngIf=\"profileForm.controls.mobile1.errors.required\">\n                This Field is Required,Enter 10 digits\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('mobile2')\" size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Contact No 2\" formControlName=\"mobile2\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('addressLine')\" size='12'>\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"locate\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Address Line1\" formControlName=\"addressLine\"></ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.addressLine.invalid\" class=\"alert alert-danger\">\n              <div *ngIf=\"profileForm.controls.addressLine.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n\n\n          <ion-col *ngIf=\"formVisible.includes('city')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"4\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"navigate\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"City\" formControlName=\"city\"></ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.city.invalid\" class=\"alert alert-danger\">\n              <div *ngIf=\"profileForm.controls.city.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('state')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"4\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"globe\"></ion-icon>\n              <!-- <ion-input type=\"text\" placeholder=\"State\" formControlName=\"state\"></ion-input> -->\n              <input style=\"\n              height: 47px;\n              border: 0px;\" list=\"state\" formControlName=\"state\" placeholder='Enter state name'\n                style=\"padding: 0px; \" />\n\n              <datalist id=\"state\">\n                <option *ngFor=\"let state of stateList\">{{state}}</option>\n              </datalist>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.state.invalid\" class=\"alert alert-danger\">\n              <div *ngIf=\"profileForm.controls.state.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('pincode')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"4\">\n            <ion-item class=\" labelSpacing\">\n              <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Pincode\" formControlName=\"pincode\"></ion-input>\n            </ion-item>\n            <div *ngIf=\"profileForm.controls.pincode.invalid\" class=\"alert alert-danger\">\n              <div *ngIf=\"profileForm.controls.pincode.errors.required\">\n                This Field is Required.\n              </div>\n            </div>\n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"formVisible.includes('manufactureYear') || formVisible.includes('registrationNumber')\">\n          <ion-col class='headerSize'> Certificate Creation</ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col *ngIf=\"formVisible.includes('registrationNumber')\" size='12' size-md=\"6\" size-lg=\"3\" size-xl=\"4\"\n            size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"card\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Registration Number\" formControlName=\"registrationNumber\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('manufactureYear')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\"\n            size-xxl=\"6\">\n            <ion-item>\n              <!-- <ion-icon name=\"list-box\"></ion-icon>/ -->\n              <ion-label> Select Manufacturer Year </ion-label>\n              <ion-datetime formControlName=\"manufactureYear\" class=\"dateFormat\" displayFormat=\"YYYY\"\n                pickerFormat=\"YYYY\" placeholder=\"YYYY\" [max]=\"maxDate\">\n              </ion-datetime>\n            </ion-item>\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('chassisNum')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\"\n            size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Chassis Number\" formControlName=\"chassisNum\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('engineNumber')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\"\n            size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"calculator\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Engine Number\" formControlName=\"engineNumber\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col *ngIf=\"formVisible.includes('vehicleMake')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\"\n            size-xxl=\"6\">\n            <ion-item (keyup)=\"changeEmpyVehicle($event)\">\n              <!-- <ion-icon name=\"list-box\"></ion-icon>/ -->\n              <ion-label>Select Vehicle</ion-label>\n              <input style=\"width: 100%;\n                height: 47px;\n                border: 0px;\" list=\"vehicle\" [(ngModel)]=\"data\" formControlName=\"vehicleMake\"\n                placeholder='Select vehicle company' style=\"padding: 0px; \" />\n              <datalist id=\"vehicle\">\n                <option *ngFor=\"let vehicle of vehicleList\">{{vehicle}}</option>\n              </datalist>\n              <!-- <ion-select formControlName=\"vehicleMake\">\n                <ion-select-option *ngFor=\"let vehicle of vehicleList\" [value]=\"vehicle\" placeholder=\"vehicle\">{{vehicle}}</ion-select-option>\n              </ion-select> -->\n            </ion-item>\n          </ion-col>\n\n          <ion-col *ngIf=\"formVisible.includes('vehicleModel')\" size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\"\n            size-xxl=\"6\">\n            <ion-item (ionChange)=\"vehicleTypeLength($event)\">\n              <ion-label>Vehicle Model</ion-label>\n              <ion-select formControlName=\"vehicleModel\">\n                <ion-select-option *ngFor=\"let vehicleModal of vehicleModal[data]\" [value]=\"vehicleModal\"\n                  placeholder=\"Address\">{{vehicleModal}}</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n\n        </ion-row>\n        <ion-row *ngIf=\"formVisible.includes('stocks')\">\n          <ion-col class='headerSize'>Stocks</ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"formVisible.includes('stocks')\">\n          <ion-col *ngIf=\"formVisible.includes('assign') && pageType != 'Certificate'\" size='12'\n            style=\"text-align: right;\">\n            <ion-item [disabled]='false' (ionChange)=\"selectedDashData($event)\">\n              <!-- <ion-icon name=\"list-box\"></ion-icon>/ -->\n              <ion-label> Select Dealer</ion-label>\n              <ion-select>\n                <ion-select-option *ngFor=\"let user of dashboardData\" [value]=\"user\">{{user.userId}}</ion-select-option>\n              </ion-select>\n            </ion-item>\n\n          </ion-col>\n\n\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Red 20mm\" formControlName=\"sred20mm\" #a\n                (ionChange)=\"changeDatas(a,'sred20mm',$event)\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Red 50mm\" formControlName=\"sred50mm\" #b\n                (ionChange)=\"changeDatas(b,'sred50mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Red 80mm\" formControlName=\"sred80mm\" #c\n                (ionChange)=\"changeDatas(c,'sred80mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"White 20mm\" formControlName=\"swhite20mm\" #d\n                (ionChange)=\"changeDatas(d,'swhite20mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"White 50mm\" formControlName=\"swhite50mm\" #e\n                (ionChange)=\"changeDatas(e,'swhite50mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"White 80mm\" formControlName=\"swhite80mm\" #f\n                (ionChange)=\"changeDatas(f,'swhite80mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Yellow 20mm\" formControlName=\"syellow20mm\" #g\n                (ionChange)=\"changeDatas(g,'syellow20mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Yellow 50mm\" formControlName=\"syellow50mm\" #h\n                (ionChange)=\"changeDatas(h,'syellow50mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\n              <ion-input type=\"number\" placeholder=\"Yellow 80mm\" formControlName=\"syellow80mm\" #i\n                (ionChange)=\"changeDatas(i,'syellow80mm')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"calculator\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Class 3\" formControlName=\"class3\" #j\n                (ionChange)=\"changeDatas(j,'class3')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"calculator\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Class 4\" formControlName=\"class4\" #k\n                (ionChange)=\"changeDatas(k,'class4')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"4\" size-xl=\"4\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\">\n\n              <ion-icon slot=\"start\" name=\"calculator\"></ion-icon>\n              <ion-input type=\"text\" placeholder=\"Hologram\" formControlName=\"hologram\" #l\n                (ionChange)=\"changeDatas(l,'hologram')\"></ion-input>\n            </ion-item>\n\n          </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"formVisible.includes('images')\">\n          <ion-col class='headerSize'>Uploading Images</ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"formVisible.includes('images')\" style=\"justify-content: center;\">\n          <ion-col size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\" style=\"text-align: center;\">\n              <ion-row>\n                <ion-col size=4>\n                  Front Image\n                </ion-col>\n                <ion-col style=\"width: 100%;\">\n                  <input type=\"file\" id=\"files\" class=\"documents\" ng2FileSelect [uploader]=\"front\">\n                </ion-col>\n              </ion-row>\n\n              <!-- <label for=\"files\" class=\"btn\">Front Image</label> -->\n\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\" style=\"text-align: center;\">\n              <ion-col size=4>\n                Back Image\n              </ion-col>\n              <ion-col>\n                <input type=\"file\" class=\"documents\" ng2FileSelect [uploader]=\"back\">\n              </ion-col>\n            </ion-item>\n\n          </ion-col>\n\n          <ion-col size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n\n            <ion-item class=\" labelSpacing\" style=\"text-align: center;\">\n              <ion-col size=3>\n                Right Image\n              </ion-col>\n              <!-- <label for=\"files\" class=\"btn\">Front Image</label> -->\n              <ion-col>\n                <input type=\"file\" id=\"files\" class=\"documents\" ng2FileSelect [uploader]=\"right\">\n              </ion-col>\n\n            </ion-item>\n\n          </ion-col>\n          <ion-col size='12' size-md=\"6\" size-lg=\"6\" size-xl=\"6\" size-xxl=\"6\">\n\n\n            <ion-item class=\" labelSpacing\" style=\"text-align: center;\">\n              <ion-col size=4>\n                Left Image\n              </ion-col>\n              <ion-col>\n                <input type=\"file\" id=\"upload_button \" class=\"documents\" ng2FileSelect [uploader]=\"left\">\n              </ion-col>\n\n            </ion-item>\n\n          </ion-col>\n        </ion-row>\n      </form>\n\n    </ion-card-content>\n    <ion-row>\n      <ion-col size=\"12\" style=\"text-align: center;\">\n        <ion-button shape=\"round\" class=\"submitBtn\" (click)=\"submit()\">submit</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-card>\n\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/common-form/common-form-routing.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/common-form/common-form-routing.module.ts ***!
      \***********************************************************/

    /*! exports provided: CommonFormPageRoutingModule */

    /***/
    function srcAppCommonFormCommonFormRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommonFormPageRoutingModule", function () {
        return CommonFormPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_form_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./common-form.page */
      "./src/app/common-form/common-form.page.ts");

      var routes = [{
        path: '',
        component: _common_form_page__WEBPACK_IMPORTED_MODULE_3__["CommonFormPage"]
      }];

      var CommonFormPageRoutingModule = function CommonFormPageRoutingModule() {
        _classCallCheck(this, CommonFormPageRoutingModule);
      };

      CommonFormPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CommonFormPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/common-form/common-form.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/common-form/common-form.module.ts ***!
      \***************************************************/

    /*! exports provided: CommonFormPageModule */

    /***/
    function srcAppCommonFormCommonFormModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommonFormPageModule", function () {
        return CommonFormPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _common_form_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./common-form-routing.module */
      "./src/app/common-form/common-form-routing.module.ts");
      /* harmony import */


      var _common_form_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./common-form.page */
      "./src/app/common-form/common-form.page.ts");
      /* harmony import */


      var ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ng2-file-upload */
      "./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js");

      var CommonFormPageModule = function CommonFormPageModule() {
        _classCallCheck(this, CommonFormPageModule);
      };

      CommonFormPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], ng2_file_upload__WEBPACK_IMPORTED_MODULE_7__["FileUploadModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _common_form_routing_module__WEBPACK_IMPORTED_MODULE_5__["CommonFormPageRoutingModule"]],
        declarations: [_common_form_page__WEBPACK_IMPORTED_MODULE_6__["CommonFormPage"]]
      })], CommonFormPageModule);
      /***/
    },

    /***/
    "./src/app/common-form/common-form.page.scss":
    /*!***************************************************!*\
      !*** ./src/app/common-form/common-form.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function srcAppCommonFormCommonFormPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".headerSize {\n  font-size: 18px;\n}\n\n.input-item {\n  border: 1px solid gray;\n  border-radius: 5px;\n  height: 40px;\n  line-height: 19px;\n}\n\n.col {\n  margin-left: 3%;\n  margin-top: 14px;\n  margin-bottom: 14px;\n}\n\n.firstcol {\n  margin-left: 5%;\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.user {\n  margin-top: 15px;\n  margin-left: 5%;\n}\n\n.col1 {\n  margin-left: 3%;\n  margin-bottom: 14px;\n  margin-top: 14px;\n}\n\n.heading {\n  background: #6c2a84;\n  border-radius: 3px;\n  padding: 4px;\n  color: white;\n}\n\n.col3 {\n  margin-left: 3%;\n  margin-bottom: 14px;\n  margin-top: 14px;\n}\n\n.col2 {\n  margin-left: 5%;\n  margin-bottom: 14px;\n  margin-top: 14px;\n}\n\ninput {\n  width: 100%;\n  height: 47px;\n  border: 0px;\n}\n\n.topBorder {\n  border-top: 6px solid red;\n}\n\n.headingClass {\n  justify-content: center;\n  font-size: x-large;\n  color: red;\n  text-transform: uppercase;\n  padding: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tbW9uLWZvcm0vY29tbW9uLWZvcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBQTtBQUFKOztBQUVBO0VBRUksc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFDQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBRUo7O0FBR0E7RUFDSSxnQkFBQTtFQUVBLGVBQUE7QUFESjs7QUFHQTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBRUE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUVBLFlBQUE7QUFBSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUVKOztBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBR0o7O0FBREE7RUFDSSx5QkFBQTtBQUlKOztBQURBO0VBQ0ksdUJBQUE7RUFDSixrQkFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGFBQUE7QUFJQSIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi1mb3JtL2NvbW1vbi1mb3JtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uaGVhZGVyU2l6ZSB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuLmlucHV0LWl0ZW0ge1xyXG4gICAgLy8gYm9yZGVyOjFweCBzb2xpZCAjZjNlM2Y2O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgZ3JheTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxOXB4O1xyXG59XHJcbi5jb2wge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMlO1xyXG4gICAgbWFyZ2luLXRvcDogMTRweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbn1cclxuLmZpcnN0Y29sIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcbi8vIC5zdWJtaXRCdG57XHJcbi8vICAgICAvLyAtLWJhY2tncm91bmQ6I2ZjZmM3MTtcclxuLy8gfVxyXG4udXNlciB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgLy8gbWFyZ2luLWxlZnQ6IDNweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxufVxyXG4uY29sMSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMyU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTRweDtcclxufVxyXG4uaGVhZGluZyB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNmMyYTg0O1xyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgcGFkZGluZzogNHB4O1xyXG5cclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uY29sMyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMyU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTRweDtcclxufVxyXG4uY29sMiB7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTRweDtcclxufVxyXG5pbnB1dHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0N3B4O1xyXG4gICAgYm9yZGVyOiAwcHg7XHJcbn1cclxuLnRvcEJvcmRlciB7XHJcbiAgICBib3JkZXItdG9wOiA2cHggc29saWQgcmVkO1xyXG59XHJcblxyXG4uaGVhZGluZ0NsYXNze1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbmZvbnQtc2l6ZTogeC1sYXJnZTtcclxuY29sb3I6IHJlZDtcclxudGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxucGFkZGluZzogMTJweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/common-form/common-form.page.ts":
    /*!*************************************************!*\
      !*** ./src/app/common-form/common-form.page.ts ***!
      \*************************************************/

    /*! exports provided: CommonFormPage */

    /***/
    function srcAppCommonFormCommonFormPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommonFormPage", function () {
        return CommonFormPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ng2-file-upload */
      "./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _services_ajax_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../services/ajax.service */
      "./src/app/services/ajax.service.ts");
      /* harmony import */


      var _services_assert_json_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../services/assert-json.service */
      "./src/app/services/assert-json.service.ts");
      /* harmony import */


      var _services_common_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../services/common.service */
      "./src/app/services/common.service.ts");
      /* harmony import */


      var _services_tapestock_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../services/tapestock.service */
      "./src/app/services/tapestock.service.ts"); // import {}


      var CommonFormPage = /*#__PURE__*/function () {
        function CommonFormPage(formBuilder, activatedRoute, storage, ajaxService, commonService, datas, router, assertJson) {
          var _this4 = this;

          _classCallCheck(this, CommonFormPage);

          this.formBuilder = formBuilder;
          this.activatedRoute = activatedRoute;
          this.storage = storage;
          this.ajaxService = ajaxService;
          this.commonService = commonService;
          this.datas = datas;
          this.router = router;
          this.assertJson = assertJson;
          this.dtoData = {
            "userId": "",
            "role": {
              "roleName": ""
            },
            "email": "",
            "password": "",
            "name": "",
            "mobile1": "",
            "mobile2": null,
            "addressLine": "",
            "city": null,
            "state": "state",
            "pincode": 8,
            "rtoZone": "",
            "class3": 0,
            "class4": 0,
            "hologram": 0,
            "createdby": "",
            "createdDate": null,
            "lastupdatedBy": null,
            "lastupdatedDate": null,
            "swhite80mm": 0,
            "swhite50mm": 0,
            "sred50mm": 0,
            "syellow50mm": 0,
            "syellow80mm": 0,
            "sred20mm": 0,
            "swhite20mm": 0,
            "sred80mm": 0,
            "syellow20mm": 0
          };
          this.certificateDtoData = {
            "certificateId": "",
            "user": null,
            "registrationNumber": "",
            "manufactureYear": null,
            "chassisNumber": "",
            "engineNumber": "",
            "vehicleMake": "",
            "vehicleModel": "",
            "ownerName": "",
            "addressLine": "",
            "city": "",
            "state": "",
            "pincode": 0,
            "rtoZone": "",
            "class3": 0,
            "class4": 0,
            "hologram": 0,
            "frontImage": "",
            "backImage": "",
            "leftImage": "",
            "rightImage": "",
            "createdDate": null,
            "updatedBy": "fg",
            "updatedDate": null,
            "rtoStatus": null,
            "rtoStatusdate": null,
            "rtoComment": null,
            "swhite20mm": 0,
            "sred80mm": 0,
            "syellow80mm": 0,
            "swhite80mm": 0,
            "syellow50mm": 0,
            "sred20mm": 0,
            "syellow20mm": 0,
            "sred50mm": 0,
            "swhite50mm": 0,
            "mobile1": null,
            "mobile2": null,
            "email": null
          };
          this.stdTapeName = ["sred50mm", "swhite50mm", "syellow50mm", "class3", "class4", "sred20mm", "swhite20mm", "sred80mm", "swhite80mm", "syellow20mm", "syellow80mm", "hologram"];
          this.stdTapeValueJson = {};
          this.count = 0;
          this.minusValue = [];
          this.dealerNames = false;
          this.uploader = false;
          this.password_type = "password";
          this.eye_icon = "eye-off";
          this.vehicleList = [];
          this.vehicleModal = []; // gokul

          this.mobnumPattern2 = "^((\\+91-?)|0)?[0-9]{10}$";
          this.stateList = [];
          this.method = "Create";
          this.right = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__["FileUploader"]({});
          this.front = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__["FileUploader"]({});
          this.back = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__["FileUploader"]({});
          this.left = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__["FileUploader"]({});
          this.rtoAreaCode = [];
          this.users = [];

          this.showHidePass = function () {
            _this4.password_type = _this4.password_type === "text" ? "password" : "text";
            _this4.eye_icon = _this4.eye_icon === "eye" ? "eye-off" : "eye";
          };

          var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/dashboard/vehicleList";
          this.ajaxService.ajaxGet(url).subscribe(function (res) {
            _this4.vehicleList = Object.keys(JSON.parse(res.value));
            _this4.vehicleModal = JSON.parse(res.value);
          });
          url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/dashboard/rtoList";
          this.ajaxService.ajaxGet(url).subscribe(function (res) {
            _this4.rtoAreaCode = JSON.parse(res.value);
          });
          url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/dashboard/states";
          this.ajaxService.ajaxGet(url).subscribe(function (res) {
            _this4.stateList = JSON.parse(res.value);
          });
        }

        _createClass(CommonFormPage, [{
          key: "addNewMember",
          value: function addNewMember() {
            var _this5 = this;

            var data = {
              type: this.profileForm.value.roleName,
              id: ""
            };
            var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/user/id/generate";
            this.ajaxService.ajaxPostWithBody(url, data).subscribe(function (res) {
              if (res.id != null) {
                console.log(res);

                for (var i = 0; i < _this5.formVisible.length; i++) {
                  if (_this5.formVisible[i] != "roleName") _this5.dtoData[_this5.formVisible[i]] = _this5.profileForm.value[_this5.formVisible[i]];else if (_this5.formVisible[i] == "roleName") _this5.dtoData["role"][_this5.formVisible[i]] = _this5.profileForm.value[_this5.formVisible[i]];
                }

                _this5.dtoData["userId"] = res.id;
                _this5.dtoData["createdby"] = _this5.loginDatas["userId"];
                _this5.dtoData["createdDate"] = new Date();

                var _url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/user/save";

                _this5.ajaxService.ajaxPostWithBody(_url, _this5.dtoData).subscribe(function (res) {
                  console.log(res);

                  if (res) {
                    _this5.loginReStore();
                  } else {
                    _this5.commonService.dismissLoader();
                  }
                });
              } else {
                _this5.commonService.presentToastWithOk("Invalid role, please select valid role");
              }
            });
          }
        }, {
          key: "vehicleTypeLength",
          value: function vehicleTypeLength(vehicleModal) {
            console.log(vehicleModal);

            for (var i = 0; i < this.stdTapeName.length; i++) {
              this.profileForm.controls[this.stdTapeName[i]].setValue(this.stdTapeValueJson[(this.profileForm.value["vehicleMake"] + "_" + vehicleModal["detail"]["value"]).replace(/ /g, "").toUpperCase()][this.stdTapeName[i]]);
            }
          }
        }, {
          key: "changeEmpyVehicle",
          value: function changeEmpyVehicle() {
            this.profileForm.controls['vehicleModel'].setValue(this.vehicleModal[this.profileForm.value['vehicleModal']]);

            for (var i = 0; i < this.stdTapeName.length; i++) {
              this.profileForm.controls[this.stdTapeName[i]].setValue("0");
            }
          }
        }, {
          key: "editSelectedMember",
          value: function editSelectedMember() {
            var _this6 = this;

            Object.assign(this.selectedData, this.profileForm.value);
            this.selectedData['lastupdatedBy'] = this.loginDatas["userId"];
            this.selectedData['lastupdatedDate'] = new Date();
            var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/user/save";
            this.ajaxService.ajaxPostWithBody(url, this.selectedData).subscribe(function (res) {
              console.log(res);

              if (res) {
                _this6.loginReStore();
              } else {
                _this6.commonService.dismissLoader();
              }
            });
          }
        }, {
          key: "stockUploader",
          value: function stockUploader() {
            var _this7 = this;

            var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + '/stock/save';
            this.loginDatas['lastupdatedBy'] = this.loginDatas.userId;
            this.loginDatas['lastupdatedDate'] = new Date();
            var data = {
              fromUser: this.loginDatas,
              toUser: null,
              message: "upload"
            };
            this.ajaxService.ajaxPostWithBody(url, data).subscribe(function (res) {
              console.log(res);

              if (res == "") {
                _this7.loginReStore();
              } else {
                _this7.commonService.dismissLoader();
              }
            });
          }
        }, {
          key: "stockAssign",
          value: function stockAssign() {
            var _this8 = this;

            this.selectedData["swhite80mm"] = this.selectedData["swhite80mm"] != null ? this.profileForm.value["swhite80mm"] == "" ? this.selectedData["swhite80mm"] : parseInt(this.profileForm.value["swhite80mm"]) + parseInt(this.selectedData["swhite80mm"]) : parseInt(this.profileForm.value["swhite80mm"]);
            this.selectedData["swhite50mm"] = this.selectedData["swhite50mm"] != null ? this.profileForm.value["swhite50mm"] == "" ? this.selectedData["swhite50mm"] : parseInt(this.profileForm.value["swhite50mm"]) + parseInt(this.selectedData["swhite50mm"]) : parseInt(this.profileForm.value["swhite50mm"]);
            this.selectedData["sred50mm"] = this.selectedData["sred50mm"] != null ? this.profileForm.value["sred50mm"] == "" ? this.selectedData["sred50mm"] : parseInt(this.profileForm.value["sred50mm"]) + parseInt(this.selectedData["sred50mm"]) : parseInt(this.profileForm.value["sred50mm"]);
            this.selectedData["syellow50mm"] = this.selectedData["syellow50mm"] != null ? this.profileForm.value["syellow50mm"] == "" ? this.selectedData["syellow50mm"] : parseInt(this.profileForm.value["syellow50mm"]) + parseInt(this.selectedData["syellow50mm"]) : parseInt(this.profileForm.value["syellow50mm"]);
            this.selectedData["syellow80mm"] = this.selectedData["syellow80mm"] != null ? this.profileForm.value["syellow80mm"] == "" ? this.selectedData["syellow80mm"] : parseInt(this.profileForm.value["syellow80mm"]) + parseInt(this.selectedData["syellow80mm"]) : parseInt(this.profileForm.value["syellow80mm"]);
            this.selectedData["sred20mm"] = this.selectedData["sred20mm"] != null ? this.profileForm.value["sred20mm"] == "" ? this.selectedData["sred20mm"] : parseInt(this.profileForm.value["sred20mm"]) + parseInt(this.selectedData["sred20mm"]) : parseInt(this.profileForm.value["sred20mm"]);
            this.selectedData["swhite20mm"] = this.selectedData["swhite20mm"] != null ? this.profileForm.value["swhite20mm"] == "" ? this.selectedData["swhite20mm"] : parseInt(this.profileForm.value["swhite20mm"]) + parseInt(this.selectedData["swhite20mm"]) : parseInt(this.profileForm.value["swhite20mm"]);
            this.selectedData["sred80mm"] = this.selectedData["sred80mm"] != null ? this.profileForm.value["sred80mm"] == "" ? this.selectedData["sred80mm"] : parseInt(this.profileForm.value["sred80mm"]) + parseInt(this.selectedData["sred80mm"]) : parseInt(this.profileForm.value["sred80mm"]);
            this.selectedData["syellow20mm"] = this.selectedData["syellow20mm"] != null ? this.profileForm.value["syellow20mm"] == "" ? this.selectedData["syellow20mm"] : parseInt(this.profileForm.value["syellow20mm"]) + parseInt(this.selectedData["syellow20mm"]) : parseInt(this.profileForm.value["syellow20mm"]);
            this.selectedData["class3"] = this.selectedData["class3"] != null ? this.profileForm.value["class3"] == "" ? this.selectedData["class3"] : parseInt(this.profileForm.value["class3"]) + parseInt(this.selectedData["class3"]) : parseInt(this.profileForm.value["class3"]);
            this.selectedData["class4"] = this.selectedData["class4"] != null ? this.profileForm.value["class4"] == "" ? this.selectedData["class4"] : parseInt(this.profileForm.value["class4"]) + parseInt(this.selectedData["class4"]) : parseInt(this.profileForm.value["class4"]);
            this.selectedData["hologram"] = this.selectedData["hologram"] != null ? this.profileForm.value["hologram"] == "" ? this.selectedData["hologram"] : parseInt(this.profileForm.value["hologram"]) + parseInt(this.selectedData["hologram"]) : parseInt(this.profileForm.value["hologram"]);
            var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + '/stock/save';
            var data = {
              fromUser: this.loginDatas,
              toUser: this.selectedData,
              message: "assign"
            };
            this.ajaxService.ajaxPostWithBody(url, data).subscribe(function (res) {
              console.log(res);

              if (res == "") {
                _this8.loginReStore();
              } else {
                _this8.commonService.dismissLoader();
              }
            });
          }
        }, {
          key: "selectedDashData",
          value: function selectedDashData(data) {
            this.selectedData = data.detail.value;
            this.selectedData['lastupdatedBy'] = this.loginDatas.userId;
            this.selectedData['lastupdatedDate'] = new Date();
          }
        }, {
          key: "loginReStore",
          value: function loginReStore() {
            var _this9 = this;

            this.storage.get("login").then(function (body) {
              var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/authentic/user";

              _this9.ajaxService.ajaxPostWithBody(url, body).subscribe(function (res) {
                // console.table(res)
                if (res != null && res != "") {
                  var messagingServiceData = res;

                  _this9.storage.set("loginRes", JSON.stringify(res)).then(function (res) {
                    _this9.commonService.updateLoginInfo(messagingServiceData);

                    _this9.router.navigateByUrl('/dashboard', {
                      replaceUrl: true
                    });
                  });
                }
              });
            });
          }
        }, {
          key: "createDealerCertificate",
          value: function createDealerCertificate() {
            var _this10 = this;

            var data = {
              type: this.profileForm.value.roleName,
              id: ""
            };
            var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/certificate/id/generate";
            this.ajaxService.ajaxPostWithBody(url, data).subscribe(function (res) {
              if (res.id != null) {
                console.log(res);
                _this10.certificateDtoData['certificateId'] = res.id;

                for (var i = 0; i < Object.keys(_this10.certificateDtoData).length; i++) {
                  if (Object.keys(_this10.certificateDtoData)[i] == "manufactureYear") {
                    _this10.certificateDtoData[Object.keys(_this10.certificateDtoData)[i]] = new Date(_this10.profileForm.value.manufactureYear).getFullYear().toString();
                  } else if (Object.keys(_this10.certificateDtoData)[i] != "certificateId" && Object.keys(_this10.certificateDtoData)[i] != "User" && _this10.profileForm.value[Object.keys(_this10.certificateDtoData)[i]] != "" && _this10.profileForm.value[Object.keys(_this10.certificateDtoData)[i]] != null && _this10.profileForm.value[Object.keys(_this10.certificateDtoData)[i]] != undefined) {
                    _this10.certificateDtoData[Object.keys(_this10.certificateDtoData)[i]] = _this10.profileForm.value[Object.keys(_this10.certificateDtoData)[i]];
                  }
                }

                _this10.certificateDtoData['user'] = _this10.loginDatas;
                _this10.certificateDtoData["createdDate"] = new Date();
                _this10.certificateDtoData["rtoStatus"] = "Pending";
                _this10.certificateDtoData["ownerName"] = _this10.profileForm.value["name"];
                var testData = new FormData();
                testData.append('right', _this10.right.queue[0]._file);
                testData.append('left', _this10.left.queue[0]._file);
                testData.append('front', _this10.front.queue[0]._file);
                testData.append('back', _this10.back.queue[0]._file);
                testData.append('data', JSON.stringify(_this10.certificateDtoData));

                var _url2 = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/certificate/save";

                _this10.ajaxService.ajaxPostWithFile(_url2, testData).subscribe(function (res) {
                  console.log(res);

                  if (res) {
                    var digits = '0123456789';
                    var OTP = '';

                    for (var _i = 0; _i < 6; _i++) {
                      OTP += digits[Math.floor(Math.random() * 10)];
                    }

                    var resu = {
                      key: res['certificateId'],
                      message: OTP
                    };

                    var _url3 = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["ServerUrl"].live + "/certificate/send/otp";

                    _this10.ajaxService.ajaxPostWithBody(_url3, resu).subscribe(function (res) {
                      _this10.commonService.presentToastWithOk(res.message);
                    });

                    _this10.loginReStore();
                  } else {
                    _this10.commonService.dismissLoader();
                  }
                });
              } else {
                _this10.commonService.presentToastWithOk("Invalid role, please select valid role");
              }
            });
          }
        }, {
          key: "createRtoCertificate",
          value: function createRtoCertificate() {}
        }, {
          key: "submit",
          value: function submit() {
            console.log(this.profileForm);

            if (this.profileForm.valid) {
              console.log('hello');
              this.commonService.presentLoader();

              if (this.pageType == "uploadStocks" && this.formVisible.includes("assign") == false) {
                this.stockUploader();
              } else if (this.pageType == "assign" && this.formVisible.includes("assign") == true) {
                this.stockAssign();
              } else if (this.pageType == "Add") {
                this.addNewMember();
              } else if (this.pageType == "Edit") {
                this.editSelectedMember();
              } else if (this.pageType == "Certificate") {
                if (this.activatedRoute.snapshot.params.type == "Dealer") this.createDealerCertificate();else this.createRtoCertificate();
              }
            } else {
              this.commonService.presentToastWithOk("Some datas are missing please fill all the requirements");
            }
          }
        }, {
          key: "changeDatas",
          value: function changeDatas(data, name, event) {
            var _this11 = this;

            if (this.formVisible.includes('assign')) {
              this.changeName = name;
              this.storage.get('loginRes').then(function (logindata) {
                logindata = JSON.parse(logindata);
                _this11.role = JSON.parse(logindata["role"]["menus"]);
                _this11.loginDatas = logindata;
                var result = _this11.loginDatas;
                name = _this11.changeName;
                _this11.orginalValues = result;

                _this11.datas.currentMessage.subscribe(function (message) {
                  return _this11.loginDatas = message;
                });

                if (_this11.orginalValues[name] >= _this11.profileForm.value[name]) {
                  for (var i = 0; i < Object.keys(_this11.orginalValues).length; i++) {
                    if (i == Object.keys(_this11.orginalValues).length) {
                      break;
                    }

                    if (Object.keys(_this11.orginalValues)[i] == name) {
                      if (data.value != "") {
                        var total = _this11.orginalValues[name] - JSON.parse(data.value);
                        _this11.loginDatas[name] = total;
                        var oldValue = JSON.parse(data.value);
                        var name = _this11.loginDatas[i];

                        _this11.minusValue.push({
                          name: oldValue
                        });
                      } else {
                        _this11.loginDatas[name] = _this11.orginalValues[name];
                      }
                    }
                  }

                  _this11.datas.changeMessage(_this11.loginDatas);
                } else {
                  alert('your value should be less than stock value');
                  _this11.loginDatas[name] = 0;

                  _this11.profileForm.controls[name].setValue(_this11.orginalValues[name]);
                }
              });
            } else {
              // this.datas.currentMessage.subscribe(message => this.loginDatas = message);
              // this.loginDatas[name] = parseInt(this.loginDatas[name]) + parseInt(this.profileForm.value[name]);
              // this.datas.changeMessage(this.loginDatas);
              this.changeName = name;
              this.storage.get('loginRes').then(function (result) {
                name = _this11.changeName;
                _this11.orginalValues = JSON.parse(result);

                _this11.datas.currentMessage.subscribe(function (message) {
                  return _this11.loginDatas = message;
                });

                for (var i = 0; i < Object.keys(_this11.orginalValues).length; i++) {
                  if (i == Object.keys(_this11.orginalValues).length) {
                    break;
                  }

                  if (Object.keys(_this11.orginalValues)[i] == name) {
                    if (data.value != "") {
                      var total = _this11.orginalValues[name] + JSON.parse(data.value);
                      _this11.loginDatas[name] = total;
                      var oldValue = JSON.parse(data.value);
                      var name = _this11.loginDatas[i];

                      _this11.minusValue.push({
                        name: oldValue
                      });
                    } else {
                      _this11.loginDatas[name] = _this11.orginalValues[name];
                    }
                  }
                }

                _this11.datas.changeMessage(_this11.loginDatas);
              });
            }
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this12 = this;

            this.stdTapeValueJson = this.assertJson.assertJson;
            var data = this.activatedRoute.snapshot.queryParamMap.get('data');
            var data1 = this.activatedRoute.snapshot.params.type;
            this.pageType = this.activatedRoute.snapshot.params.method;
            this.storage.get('dashboardResult').then(function (result) {
              result = JSON.parse(result);
              _this12.dashboardData = result;
            });
            this.storage.get('loginRes').then(function (result) {
              result = JSON.parse(result);
              _this12.role = JSON.parse(result["role"]["menus"]);
              _this12.loginDatas = result;
            });

            if (data1 == "SuperAdmin") {
              this.creation = this.method + " a manufacturer";
              this.formVisible = ["userId", "password", "roleName", "email", "name", "mobile1", "mobile2", "addressLine", "city", "state", "pincode", "rtoZone"];
              this.profileForm = this.formBuilder.group({
                name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                roleName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]],
                mobile1: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.mobnumPattern2)]],
                mobile2: [''],
                state: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              });
            } else if (data1 == "Manufacturer") {
              this.creation = this.method + " a distributor";
              this.formVisible = ["userId", "password", "roleName", "email", "name", "mobile1", "mobile2", "addressLine", "city", "state", "pincode", "rtoZone"];
              this.profileForm = this.formBuilder.group({
                name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                roleName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]],
                mobile1: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.mobnumPattern2)]],
                mobile2: [''],
                state: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              });
            } else if (data1 == "Distributor") {
              this.creation = this.method + " a dealer";
              this.formVisible = ["userId", "password", "roleName", "email", "name", "mobile1", "mobile2", "addressLine", "city", "state", "pincode", "rtoZone"];
              this.profileForm = this.formBuilder.group({
                name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                roleName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]],
                mobile1: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.mobnumPattern2)]],
                mobile2: [''],
                state: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              });
            } else if (data1 == "Dealer") {
              this.creation = this.method + " a certificate";
              this.formVisible = ["userId", "roleName", "email", // "password",
              "name", "mobile1", "mobile2", "addressLine", "city", "state", "pincode", "rtoZone", "chassisNum", "registrationNumber", "manufactureYear", "engineNumber", "vehicleMake", "vehicleModel", "class4", "class3", "hologram", "stocks", "images", "assign"];
              this.profileForm = this.formBuilder.group({
                name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: [''],
                roleName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                // call: ['', Validators.required],
                email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]],
                mobile1: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.mobnumPattern2)]],
                mobile2: [''],
                state: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                //  stocks
                sred20mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                sred50mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                sred80mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite20mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite50mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite80mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow20mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow50mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow80mm: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                // CERTIFICATE creation
                registrationNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                manufactureYear: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                chassisNum: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                engineNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                vehicleMake: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                vehicleModel: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                class3: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                class4: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                hologram: ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              });
            } else if (data1 == "Rto") {
              this.creation = this.method + " a certificate";
              this.formVisible = ["userId", "roleName", "email", // "password",
              "name", "mobile1", "mobile2", "addressLine", "city", "state", "pincode", "rtoZone", "registrationNumber", "manufactureYear", "engineNumber", "vehicleMake", "vehicleModel", "class4", "class3", "chassisNum", "hologram", "stocks", "images", "assign"];
              this.profileForm = this.formBuilder.group({
                name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: [''],
                roleName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                // call: ['', Validators.required],
                email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                mobile1: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                mobile2: [''],
                state: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                //  stocks
                sred20mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                sred50mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                sred80mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite20mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite50mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                swhite80mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow20mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow50mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                syellow80mm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                // CERTIFICATE creation
                registrationNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                manufactureYear: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                chassisNum: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                engineNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                vehicleMake: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                vehicleModel: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                class3: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                class4: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                hologram: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
              });
            } else if (data1 == "uploadStocks") {
              this.creation = "upload stocks";
              this.formVisible = ["stocks"];
              this.profileForm = this.formBuilder.group({
                sred20mm: [''],
                sred50mm: [''],
                sred80mm: [''],
                swhite20mm: [''],
                swhite50mm: [''],
                swhite80mm: [''],
                syellow20mm: [''],
                syellow50mm: [''],
                syellow80mm: [''],
                class3: [''],
                class4: [''],
                hologram: ['']
              });
            } else if (data1 == "assign") {
              this.creation = "Assign stocks to dealer";
              this.formVisible = ["stocks", "assign"];
              this.profileForm = this.formBuilder.group({
                sred20mm: [''],
                sred50mm: [''],
                sred80mm: [''],
                swhite20mm: [''],
                swhite50mm: [''],
                swhite80mm: [''],
                syellow20mm: [''],
                syellow50mm: [''],
                syellow80mm: [''],
                class3: [''],
                class4: [''],
                hologram: ['']
              });
            }

            data = JSON.parse(data);

            if (data == "null" || data == null) {// this.profileForm = this.formBuilder.group({
              //   name: ['', Validators.required],
              //   password: ['', Validators.required],
              //   roleName: ['', Validators.required],
              //   rtoZone: ['', Validators.required],
              //   call: ['', Validators.required],
              //   email: ['', Validators.required],
              //   mobile1: ['', Validators.required],
              //   mobile2: [''],
              //   state: ['', Validators.required],
              //   city: ['', Validators.required],
              //   addressLine: ['', Validators.required],
              //   pincode: ['', Validators.required],
              //   //  stocks
              //   sred20mm: ['', Validators.required],
              //   sred50mm: ['', Validators.required],
              //   sred80mm: ['', Validators.required],
              //   swhite20mm: ['', Validators.required],
              //   swhite50mm: ['', Validators.required],
              //   swhite80mm: ['', Validators.required],
              //   syellow20mm: ['', Validators.required],
              //   syellow50mm: ['', Validators.required],
              //   syellow80mm: ['', Validators.required],
              //   // CERTIFICATE creation
              //   registrationNumber: ['', Validators.required],
              //   manufactureYear: ['', Validators.required],
              //   chassisNum: ['', Validators.required],
              //   engineNumber: ['', Validators.required],
              //   vehicleMake: ['', Validators.required],
              //   vehicleModel: ['', Validators.required],
              //   class3: ['', Validators.required],
              //   class4: ['', Validators.required],
              //   hologram: ['', Validators.required],
              // });
            } else {
              this.selectedData = data;
              this.method = 'edit';
              this.profileForm = this.formBuilder.group({
                name: [data.name, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: [data.password, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                roleName: [data.role.roleName, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoZone: [data.rtoZone, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                call: [data.cell, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                email: [data.email, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                mobile1: [data.mobile1, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                mobile2: [data.mobile2, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                state: [data.state, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                city: [data.city, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                addressLine: [data.addressLine, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pincode: [data.pincode, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                //  stocks
                sred20mm: [data.sred20mm],
                sred50mm: [data.sred50mm],
                sred80mm: [data.sred80mm],
                swhite20mm: [data.swhite20mm],
                swhite50mm: [data.swhite50mm],
                swhite80mm: [data.swhite80mm],
                syellow20mm: [data.syellow20mm],
                syellow50mm: [data.syellow50mm],
                syellow80mm: [data.syellow80mm],
                // CERTIFICATE creation
                registrationNumber: [data.registrationNumber],
                manufactureYear: [data.manufactureYear],
                chassisNum: [data.chassisNum],
                engineNumber: [data.engineNumber],
                vehicleMake: [data.vehicleMake],
                vehicleModel: [data.vehicleModel],
                class3: [data.class3],
                class4: [data.class4],
                hologram: [data.hologram]
              });
            }
          }
        }]);

        return CommonFormPage;
      }();

      CommonFormPage.ctorParameters = function () {
        return [{
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"]
        }, {
          type: _services_ajax_service__WEBPACK_IMPORTED_MODULE_7__["AjaxService"]
        }, {
          type: _services_common_service__WEBPACK_IMPORTED_MODULE_9__["CommonServices"]
        }, {
          type: _services_tapestock_service__WEBPACK_IMPORTED_MODULE_10__["TapestockService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _services_assert_json_service__WEBPACK_IMPORTED_MODULE_8__["AssertJsonService"]
        }];
      };

      CommonFormPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-common-form',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./common-form.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/common-form/common-form.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./common-form.page.scss */
        "./src/app/common-form/common-form.page.scss"))["default"]]
      })], CommonFormPage);
      /***/
    },

    /***/
    "./src/app/services/assert-json.service.ts":
    /*!*************************************************!*\
      !*** ./src/app/services/assert-json.service.ts ***!
      \*************************************************/

    /*! exports provided: AssertJsonService */

    /***/
    function srcAppServicesAssertJsonServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AssertJsonService", function () {
        return AssertJsonService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var AssertJsonService = function AssertJsonService() {
        _classCallCheck(this, AssertJsonService);

        this.assertJson = {
          "AMW_2518TRUCK": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "15",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "AMW_BULKER": {
            "sred50mm": "8",
            "swhite50mm": "7",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "AMW_TAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "AMW_TANKER": {
            "sred50mm": "5",
            "swhite50mm": "6",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "APE_APEAUTO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.1",
            "swhite20mm": "1.4",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_1214CONTAINER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_1618CONTAINER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "21",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_3516TAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_3516TANKER": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_3517TAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "22",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_3518TANKER": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1112": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1212": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1214SMART": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1612": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1613": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1613TIPPER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL1616": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL2513": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL2516": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL2516TIPPER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL2518": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL3116": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL3118": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL3718": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_AL4018": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "25",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALBOSS1212LE": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALCG": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALCT1613": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALCTTIPPER1616XL": {
            "sred50mm": "2.5",
            "swhite50mm": "2.8",
            "syellow50mm": "10.5",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALECOMET912": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALECOMET1012": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALFSV3/46LYNX": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALFV4923": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALLYNX": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPARTNER": {
            "sred50mm": "1.75",
            "swhite50mm": "1.75",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPEV1/38": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/38": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/88": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/89": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/161": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/185": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSV4/186": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALPSVVIKING4/83": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALTAURUS2516": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALTUSKERSUPER2214": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALU2518": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALU2523": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ALVIKINGBUS": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_BOSS1115CONTAINER": {
            "sred50mm": "9",
            "swhite50mm": "2.25",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_BOSS1212": {
            "sred50mm": "3",
            "swhite50mm": "3",
            "syellow50mm": "21",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_COMET1611": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_DOST": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "8",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ECOMET1109": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_ECOMET1212": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASHOKLEYLAND_VIKINGALPSV4/247": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ASOAMOTOR_AMW2518": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ATUL_ATUL": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "BAJAJTEMPO_TEMPOTRAXJUDO/GAMA": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "6.5",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "BAJAJ_BAJAJAUTO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.25",
            "swhite20mm": "1.4",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "BAJAJ_BAJAJTEMPO": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "BAJAJ_TRAVELLERCRUSIER": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "9",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_BHARATBENZ914R": {
            "sred50mm": "2.15",
            "swhite50mm": "2.15",
            "syellow50mm": "12.3",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_BHARATBENZ1214R": {
            "sred50mm": "4",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_BHARATBENZ1617TANKER": {
            "sred50mm": "1.8",
            "swhite50mm": "1.8",
            "syellow50mm": "13",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_BHARATBENZ2523C": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_BHARATBENZ2528": {
            "sred50mm": "2.5",
            "swhite50mm": "2",
            "syellow50mm": "14",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_TTBULKER": {
            "sred50mm": "8",
            "swhite50mm": "2.5",
            "syellow50mm": "30",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_TTTAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "DAIMLERINDIACOMERCIALVEHICLE_TTTANKER": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "FORCEMOTOR_FORCETRAVELER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "9",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "FORCEMOTOR_TEMPOTRAVELLER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "FORCEMOTOR_TRUMP40PICKUP": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "FORD_FIGO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "GENERALMOTORS_CHEVEROLETBEAT": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "GENERALMOTORS_CHEVEROLETENJOY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "GENERALMOTORS_CHEVEROLETSAIL": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "GENERALMOTORS_CHEVEROLETTAVERA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HINDUSTANMOTOR_AMBASSDOR": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HONDA_AMAZE": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HONDA_CITY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HONDA_MOBILIO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HYUNDAI_EON": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HYUNDAI_GRAND": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HYUNDAI_SANTRO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HYUNDAI_XCENT": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "HYUNDAI_i10": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "ISUZUMOTORS_DMAXFLATDECK": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_BLAZO": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_BOLERO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_BOLEROPICKUP": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_DI3200": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "8",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_GENIO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_JEETO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_KUV100": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_LOADKING": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "7",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_LOGAN": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_MARSHAL2000": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "5",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_MAXICAB": {
            "sred50mm": "1.75",
            "swhite50mm": "1.75",
            "syellow50mm": "9",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_MAXXIMO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_MAXXMAXITRUCK": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_NAVISTER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_SCORPIO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_SUPROMINIVAN": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "7",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_TOURISTER": {
            "sred50mm": "1.75",
            "swhite50mm": "1.75",
            "syellow50mm": "10",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_TRACTOR": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "3",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_TRACTORwithSHORTTRAILER": {
            "sred50mm": "1.8",
            "swhite50mm": "1",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_TRACTORwithTRAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "1.5",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_TUV300": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_VERITO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_XUV500": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAHINDRA&MAHINDRA_XYLO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAN_CLA16.220": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAN_CLABULKER": {
            "sred50mm": "8",
            "swhite50mm": "2.5",
            "syellow50mm": "30",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAN_CLATAILER": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAN_CLATANKER": {
            "sred50mm": "5",
            "swhite50mm": "4",
            "syellow50mm": "23",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MAN_MAN25.250TRUCK": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_ALTOK10": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_CELERIO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_EECO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_ERTIGA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_ESTEEM": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_GYPSY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_OMINI": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_RITZ": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_SUPERCARRY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.5",
            "swhite20mm": "1.5",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_SWIFT": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_SWIFTDZIRE": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_VERSA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "MARUTHISUZUKI_WAGONR": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "NISSAN_DATSUNGO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "NISSAN_LODGY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.5",
            "swhite20mm": "1.5",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "NISSAN_MICRA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "NISSAN_SUNNY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "PIAGGO_APE": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.25",
            "swhite20mm": "1.25",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "PIAGGO_APECARGO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.5",
            "swhite20mm": "1.5",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "PIAGGO_APEXTRALD": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.5",
            "swhite20mm": "1.5",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "PIAGGO_PORTER600": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.3",
            "swhite20mm": "1.3",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "RENAULT_KWID": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "RENAULT_LODGY": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SCHWINGSTETTER(INDIA)PVTLTD_SLM4000": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_OMNIBUS": {
            "sred50mm": "1.5",
            "swhite50mm": "1.5",
            "syellow50mm": "12",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SAMRAT": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SAMRATTURBO": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SARTAJ": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SMLISUZUWV26T3500": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SMLMAXICAB": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_SUPER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_T3500": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_T3500BUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_WT48E": {
            "sred50mm": "2",
            "swhite50mm": "1.5",
            "syellow50mm": "10",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "SWARAJMAZDA_ZT54": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA207": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA218": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.3",
            "swhite20mm": "1.3",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA407": {
            "sred50mm": "2",
            "swhite50mm": "1.7",
            "syellow50mm": "8",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA410": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "8",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA709": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA709STARBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA712": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "14",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA712STARBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA909": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10.5",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA912": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1109": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1210": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1510": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1512": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1612": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1613": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1615": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA1616": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA2515": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA2516": {
            "sred50mm": "2",
            "swhite50mm": "2.3",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA2518": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3118": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3516": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3516BULKER": {
            "sred50mm": "8",
            "swhite50mm": "2.5",
            "syellow50mm": "30",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3516TANKAR": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3516TRAILAR": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3518BULKER": {
            "sred50mm": "8",
            "swhite50mm": "2.5",
            "syellow50mm": "30",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3518TANKAR": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3518TRAILAR": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA3718": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA4018": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "25",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA4018BULKER": {
            "sred50mm": "8",
            "swhite50mm": "2.5",
            "syellow50mm": "30",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA4018TANKAR": {
            "sred50mm": "5",
            "swhite50mm": "2.5",
            "syellow50mm": "21",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATA4018TRAILAR": {
            "sred50mm": "2.5",
            "swhite50mm": "2.5",
            "syellow50mm": "28",
            "class3": "0",
            "class4": "1",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAACE": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATABOLT": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATACITYRIDEBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAINDICA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAINDIGO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATALPT1412": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "12",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATALPT1612": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAMAGIC": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "2",
            "swhite20mm": "2",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAMAGICIRISH": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAMARCOPOLOSTARBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATASUMO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATASUPERACE": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATATIAGO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAULTRA912": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAULTRA1012": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAWINGER": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAXENONPICKUP": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.5",
            "swhite20mm": "1.5",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TATAMOTORS_TATAZEST": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TOYOTAKIRLOKAR_ETIOS": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TOYOTAKIRLOKAR_ETIOSLIVA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TOYOTAKIRLOKAR_INNOVA": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.75",
            "swhite20mm": "1.75",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "TVS_AUTO": {
            "sred50mm": "0",
            "swhite50mm": "0",
            "syellow50mm": "0",
            "class3": "0",
            "class4": "0",
            "sred20mm": "1.1",
            "swhite20mm": "1.4",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.50": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.50CBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "8",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.50DBUS": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.59": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.60": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.70": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.75": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.80": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.90": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER10.95": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER11.10": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER11.12": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER20.15": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER20.16": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHER30.25": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERLGVOLD": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "10",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERMAXICAB": {
            "sred50mm": "2.5",
            "swhite50mm": "1.75",
            "syellow50mm": "10.5",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERMITSUBISHICANTER": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "16",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERPRO1049": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "7",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERPRO5016": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "18",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_EICHERTERRA16": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "20",
            "class3": "1",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          },
          "VECOMMERCIAL_MOTORDVAN150HP": {
            "sred50mm": "2",
            "swhite50mm": "2",
            "syellow50mm": "6",
            "class3": "0",
            "class4": "0",
            "sred20mm": "0",
            "swhite20mm": "0",
            "sred80mm": "0",
            "swhite80mm": "0",
            "syellow20mm": "0",
            "syellow80mm": "0",
            "hologram": "0"
          }
        };
      };

      AssertJsonService.ctorParameters = function () {
        return [];
      };

      AssertJsonService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AssertJsonService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=common-form-common-form-module-es5.js.map