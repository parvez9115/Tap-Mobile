(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <div  [style.background-image]=\"'url('+ background +')'\" [style.background-size]= \"'cover'\"  class='container'>\n    <div class=\"moveAndTrackSpacingNew ion-align-items-center ion-justify-content-center\" size-md =\"6 \" size-lg =\"6\" size-xs =\"12\" >\n\n        <form   style=\"padding-top: 10%;\" [formGroup]=\"login\" >\n            <ion-item *ngIf=\"pageSelection == 'userLogin'\" class=\" labelSpacing\">\n                <ion-icon slot=\"start\" name=\"person\"></ion-icon>\n                <ion-input formControlName=\"compName\" placeholder=\"Username\" autocomplete=\"off\"></ion-input>\n            </ion-item>\n            <ion-item *ngIf=\"pageSelection == 'rtoLogin'\" class=\"labelSpacing\">\n              <ion-icon slot=\"start\" name=\"person\"></ion-icon>\n              <!-- <ion-select interface=\"popover\" style=\"width: 100%;\" placeholder=\"Select rto area\" formControlName=\"rtoArea\">\n                <ion-select-option  *ngFor=\"let rto of rtos\" >{{rto}}</ion-select-option>\n                </ion-select> -->\n                <input style= \"width: 100%; \n                height: 47px;\n                border: 0px;\"  autocomplete=\"off\" list=\"num\"  formControlName=\"rtoArea\"  placeholder = 'Select rto area' style=\"padding: 0px;background-color: white; \" />\n             \n                <datalist id=\"num\">\n                <option *ngFor=\"let rto of rtos\" >{{rto}}</option>\n                </datalist>\n                <!-- <ionic-selectable class=\"maxWidth\" formControlName=\"rtoArea\" [items]=\"rtos\"\n                itemTextField=\"rtos\" [canSearch]=\"true\" (onChange)=\"portChange($event)\" [hasVirtualScroll]=\"true\"\n                placeholder=\"Select rto area\">\n              </ionic-selectable> -->\n              </ion-item>\n            <ion-item  class=\" labelSpacing\">\n                <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n                <ion-input formControlName=\"password\" placeholder=\"Password\" (keyup.enter)=\"submitLogin()\" [type]=\"password_type\">\n                </ion-input>\n                <ion-icon slot=\"end\" [name]=\"eye_icon\" (click)=\"showHidePass()\"></ion-icon>\n            </ion-item>\n        </form>\n        <ion-row>\n            <ion-col size=\"6\" offset=\"3\">\n                <ion-button [class]=\"appName\" (click)=\"submitLogin()\" \n                shape=\"round\" expand=\"block\"\n                [disabled]=\"!login.valid\">\n                <ion-icon name=\"log-in\" class=\"iconSize\"></ion-icon> Login\n            </ion-button>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"6\" offset=\"3\">\n            <ion-button  (click)=\"changeMode()\"   shape=\"round\" expand=\"block\">{{buttonName}}</ion-button>\n    </ion-col>\n  </ion-row>\n      </div>\n</div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/login/login-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/login/login-routing.module.ts");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







// import { IonicSelectableModule } from 'ionic-selectable';

let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            // IonicSelectableModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-input .native-input {\n  border-radius: 25px;\n}\n\n#num {\n  background-color: white;\n  color: black;\n}\n\n.labelSpacing {\n  margin-bottom: 3%;\n  margin-left: 6%;\n  width: 85%;\n}\n\ninput {\n  width: 100%;\n  height: 47px;\n  border: 0px;\n}\n\n.imagedata {\n  background-size: cover;\n}\n\n.moveAndTrackSpacing {\n  opacity: 0.9;\n  width: 300px;\n  margin: auto;\n  position: relative;\n  top: 50px;\n  border-radius: 5px;\n}\n\n@media only screen and (min-width: 1024px) {\n  .moveAndTrackSpacing {\n    margin: auto;\n    position: relative;\n    top: 17vh;\n  }\n\n  .moveAndTrackSpacingNew {\n    position: absolute;\n    right: 8px;\n    top: 27vh;\n    background: #f1f1f170;\n  }\n}\n\n@media only screen and (max-width: 550px) {\n  .moveAndTrackSpacing {\n    position: relative;\n    top: 50px;\n  }\n}\n\n@media only screen and (min-width: 551px) {\n  .moveAndTrackSpacing {\n    width: 360px;\n  }\n\n  .moveAndTrackSpacingNew {\n    width: 360px;\n  }\n}\n\n.container {\n  margin: 0px;\n  height: 100vh;\n  display: block;\n}\n\n.text-box-spacing {\n  height: 60px;\n}\n\n.labelSpacing-web {\n  margin-bottom: 3%;\n}\n\n.left-side-form-grp {\n  width: 20%;\n  position: fixed;\n  top: 10vh;\n  right: 2vh;\n}\n\n.container-wrapper {\n  margin: 0px;\n  height: 100vh;\n  display: block;\n  background: url(\"https://kingstrackimages.s3.amazonaws.com/loginimages/track_apmkingstrack_com_background.jpg\") center center/cover no-repeat fixed;\n}\n\n.labelSpacing {\n  margin-bottom: 3%;\n  margin-left: 6%;\n  width: 85%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0ksbUJBQUE7QUFEUjs7QUFJQTtFQUNJLHVCQUFBO0VBQ0EsWUFBQTtBQURKOztBQUdBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQUFKOztBQUdBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQUo7O0FBR0E7RUFDSSxzQkFBQTtBQUFKOztBQUdBO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFJQTtFQUNJO0lBQ0ksWUFBQTtJQUNBLGtCQUFBO0lBQ0EsU0FBQTtFQUROOztFQUdFO0lBQ0ksa0JBQUE7SUFDQSxVQUFBO0lBQ0EsU0FBQTtJQUNBLHFCQUFBO0VBQU47QUFDRjs7QUFHRTtFQUNFO0lBQ0ksa0JBQUE7SUFDQSxTQUFBO0VBRE47QUFDRjs7QUFJRTtFQUNFO0lBQ0ssWUFBQTtFQUZQOztFQUlFO0lBQ0ksWUFBQTtFQUROO0FBQ0Y7O0FBS0E7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7QUFISjs7QUFNQTtFQUNBLFlBQUE7QUFIQTs7QUFNQTtFQUNJLGlCQUFBO0FBSEo7O0FBTUE7RUFDSSxVQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBSEo7O0FBS0E7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxtSkFBQTtBQUZKOztBQUlBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQURKIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5pb24taW5wdXQge1xuICAgIC5uYXRpdmUtaW5wdXQge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4XG4gICAgfVxufVxuI251bXtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICBjb2xvcjogYmxhY2s7XG59XG4ubGFiZWxTcGFjaW5ne1xuICAgIG1hcmdpbi1ib3R0b206IDMlO1xuICAgIG1hcmdpbi1sZWZ0OiA2JTtcbiAgICB3aWR0aDogODUlO1xufVxuXG5pbnB1dHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDQ3cHg7XG4gICAgYm9yZGVyOiAwcHg7XG59XG5cbi5pbWFnZWRhdGF7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuLm1vdmVBbmRUcmFja1NwYWNpbmd7XG4gICAgb3BhY2l0eTogMC45O1xuICAgIHdpZHRoOiAzMDBweDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogNTBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgXG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTAyNHB4KSB7XG4gICAgLm1vdmVBbmRUcmFja1NwYWNpbmcge1xuICAgICAgICBtYXJnaW46YXV0bztcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6MTd2aDtcbiAgICB9XG4gICAgLm1vdmVBbmRUcmFja1NwYWNpbmdOZXcge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHJpZ2h0OiA4cHg7XG4gICAgICAgIHRvcDogMjd2aDtcbiAgICAgICAgYmFja2dyb3VuZDogI2YxZjFmMTcwO1xuICAgIH1cbiAgICBcbiAgfVxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSAge1xuICAgIC5tb3ZlQW5kVHJhY2tTcGFjaW5nIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IDUwcHg7XG4gICAgfVxuICAgIFxuICB9XG4gIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDo1NTFweCl7XG4gICAgLm1vdmVBbmRUcmFja1NwYWNpbmcge1xuICAgICAgICAgd2lkdGg6IDM2MHB4O1xuICAgIH0gXG4gICAgLm1vdmVBbmRUcmFja1NwYWNpbmdOZXcge1xuICAgICAgICB3aWR0aDogMzYwcHg7XG4gICB9IFxuICB9XG5cblxuLmNvbnRhaW5lcntcbiAgICBtYXJnaW46IDBweDtcbiAgICBoZWlnaHQ6IDEwMHZoO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4udGV4dC1ib3gtc3BhY2luZ3tcbmhlaWdodDogNjBweDtcbn1cblxuLmxhYmVsU3BhY2luZy13ZWIge1xuICAgIG1hcmdpbi1ib3R0b206IDMlO1xufVxuXG4ubGVmdC1zaWRlLWZvcm0tZ3Jwe1xuICAgIHdpZHRoOiAyMCU7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHRvcDogMTB2aDtcbiAgICByaWdodDogMnZoO1xufVxuLmNvbnRhaW5lci13cmFwcGVye1xuICAgIG1hcmdpbjogMHB4O1xuICAgIGhlaWdodDogMTAwdmg7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgYmFja2dyb3VuZDogdXJsKFwiaHR0cHM6Ly9raW5nc3RyYWNraW1hZ2VzLnMzLmFtYXpvbmF3cy5jb20vbG9naW5pbWFnZXMvdHJhY2tfYXBta2luZ3N0cmFja19jb21fYmFja2dyb3VuZC5qcGdcIikgY2VudGVyIGNlbnRlciAvIGNvdmVyIG5vLXJlcGVhdCBmaXhlZDsgIFxufVxuLmxhYmVsU3BhY2luZ3tcbiAgICBtYXJnaW4tYm90dG9tOiAzJTtcbiAgICBtYXJnaW4tbGVmdDogNiU7XG4gICAgd2lkdGg6IDg1JTtcbn1cblxuIl19 */");

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_ajax_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/ajax.service */ "./src/app/services/ajax.service.ts");
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/common.service */ "./src/app/services/common.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");









// import { IonicSelectableComponent } from 'ionic-selectable';
let LoginPage = class LoginPage {
    constructor(menuController, formBuilder, commonService, router, ajaxService, storage) {
        this.menuController = menuController;
        this.formBuilder = formBuilder;
        this.commonService = commonService;
        this.router = router;
        this.ajaxService = ajaxService;
        this.storage = storage;
        this.eye_icon = "eye-off";
        this.password_type = "password";
        this.pageSelection = "userLogin";
        this.rtos = [];
        this.buttonName = "Rto Login";
        this.showHidePass = () => {
            this.password_type = this.password_type === "text" ? "password" : "text";
            this.eye_icon = this.eye_icon === "eye" ? "eye-off" : "eye";
        };
        let url = src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["ServerUrl"].live + "/dashboard/background";
        this.ajaxService.ajaxGet(url)
            .subscribe(res => {
            this.background = res.value;
        });
        url = src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["ServerUrl"].live + "/dashboard/rtoList";
        this.ajaxService.ajaxGet(url)
            .subscribe(res => {
            this.rtos = JSON.parse(res.value);
        });
    }
    submitLogin() {
        if (!this.commonService.isLoading)
            this.commonService.presentLoader();
        let body = {};
        if (this.pageSelection == "userLogin") {
            body = {
                "email": this.login.value.compName.toString(),
                "password": this.login.value.password.toString()
            };
        }
        else {
            body = {
                "email": this.login.value.rtoArea.toString(),
                "password": this.login.value.password.toString()
            };
        }
        this.storage.set("login", JSON.stringify(body));
        let url = src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["ServerUrl"].live + "/authentic/user";
        this.ajaxService.ajaxPostWithBody(url, body)
            .subscribe(res => {
            // console.table(res)
            if (res != null && res != "") {
                let messagingServiceData = res;
                this.storage.set("loginRes", JSON.stringify(res)).then(res => {
                    this.commonService.updateLoginInfo(messagingServiceData);
                    if (this.pageSelection == "userLogin") {
                        this.router.navigateByUrl('/dashboard', { replaceUrl: true });
                    }
                    else {
                        this.router.navigateByUrl('/rto-dashboard', { replaceUrl: true });
                    }
                });
            }
            else if (res == "") {
                if (this.commonService.isLoading)
                    this.commonService.dismissLoader();
                let msg = "Your logging credential is invalid ";
                this.commonService.presentToastWithOk(msg);
            }
            else {
                if (navigator.onLine) {
                    if (this.commonService.isLoading)
                        this.commonService.dismissLoader();
                    let msg = "Oops! Server is in under maintenance";
                    this.commonService.presentToastWithOk(msg);
                }
                else {
                    if (this.commonService.isLoading)
                        this.commonService.dismissLoader();
                    let msg = "Oops! Connecting server error, Make sure your internet connection";
                    this.commonService.presentToastWithOk(msg);
                }
            }
        });
        // } 
        // else {
        // let body = {
        //   "email": "TN-01",
        //   "password": this.login.value.password.toString()
        // };
        // this.storage.set("login", JSON.stringify(body));
        // let url = ServerUrl.live + "/authentic/user";
        // this.ajaxService.ajaxPostWithBody(url, body)
        //   .subscribe(res => {
        //     let messagingServiceData = res
        //     if (res != null && res != "") {
        //       this.storage.set("loginRes", JSON.stringify(res)).then(res => {
        //         this.commonService.updateLoginInfo(messagingServiceData);
        //         this.router.navigateByUrl('/rto-dashboard')
        //       });
        //     } if (res == "") {
        //       if (this.commonService.isLoading)
        //         this.commonService.dismissLoader();
        //       let msg = "Your logging credential is invalid "
        //       this.commonService.presentToastWithOk(msg)
        //     } else {
        //       if (this.commonService.isLoading)
        //         this.commonService.dismissLoader();
        //       let msg = "Oops! Server is in under maintenance"
        //       this.commonService.presentToastWithOk(msg)
        //     }
        //   });
        // }
    }
    // portChange = (event: {
    //   component: IonicSelectableComponent,
    //   value: any
    // }) => {
    //   this.login= event.value;
    // }
    changeMode() {
        let data = this.pageSelection;
        if (data == 'userLogin') {
            this.pageSelection = "rtoLogin";
            this.buttonName = "User Login";
            this.login = this.formBuilder.group({
                compName: [''],
                rtoArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            });
        }
        else {
            this.pageSelection = "userLogin";
            this.buttonName = "Rto Login";
            this.login = this.formBuilder.group({
                compName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                rtoArea: [''],
                password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            });
        }
    }
    ionViewWillEnter() {
        this.menuController.enable(false);
        this.storage.clear();
    }
    ngOnInit() {
        this.menuController.enable(false);
        this.login = this.formBuilder.group({
            compName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            rtoArea: [''],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_6__["CommonServices"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _services_ajax_service__WEBPACK_IMPORTED_MODULE_5__["AjaxService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")).default]
    })
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map