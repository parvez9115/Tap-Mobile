import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ColumnMode, DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-super-admin',
  templateUrl: './super-admin.component.html',
  styleUrls: ['./super-admin.component.scss'],
})
export class SuperAdminComponent implements OnInit {
  @ViewChild('myTable') table: DatatableComponent;
  ColumnMode = ColumnMode
  @Input() memberList = [];
  temp = [];
  @Input() userRole: string;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router

  ) { }

  updateFilter(event) {
    if (event.target.value != "") {
      const val = event.target.value.toLowerCase();
      const temp = this.temp.filter(function (d) {
        if (d.name.toLowerCase().indexOf(val) !== -1)
          return d.name.toLowerCase().indexOf(val) !== -1;
        else if (d.userId.toLowerCase().indexOf(val) !== -1)
          return d.userId.toLowerCase().indexOf(val) !== -1;
        else if (d.role.roleName.toLowerCase().indexOf(val) !== -1)
          return d.role.roleName.toLowerCase().indexOf(val) !== -1;
        else if (d.email.toLowerCase().indexOf(val) !== -1)
          return d.email.toLowerCase().indexOf(val) !== -1;
        else if (d.mobile1.toLowerCase().indexOf(val) !== -1)
          return d.mobile1.toLowerCase().indexOf(val) !== -1;
      });
      this.memberList = temp;
    } else {
      this.memberList = this.temp
    }
    // Whenever the filter changes, always go back to the first page
    this.table["table"].offset = 0;
  }

  onActivate(event) {
    if (event.type == 'click') {
      console.log(event.row);
    }
  }

  async openModalStocks(data) {
    this.router.navigateByUrl("/common-form/" + data + "/" + data + "/null", { replaceUrl: true })
  }

  selectedRowRecived(data) {
    this.router.navigateByUrl("/common-form/Edit/" + this.userRole + "/?data=" + JSON.stringify(data), { replaceUrl: true })
  }

  async openModal() {
    this.router.navigateByUrl("/common-form/Add/" + this.userRole + "/null", { replaceUrl: true })
  }

  ngOnChanges() {
    this.temp = this.memberList
  }

  ngOnInit() {
    this.temp = this.memberList
    this.formBuilder.group({
      userName: [""]
    })
  }

}
