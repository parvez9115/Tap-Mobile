import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { AjaxService } from 'src/app/services/ajax.service';
import { ServerUrl } from 'src/environments/environment';

@Component({
  selector: 'app-status-modal',
  templateUrl: './status-modal.page.html',
  styleUrls: ['./status-modal.page.scss'],
})
export class StatusModalPage implements OnInit {
  @Input() shownContent;
  textBox
  verifiedData: any;
  otp
  statusNames = ["Pending", "Recheck", "Verified", "Rejected"]
  showContent: boolean = false;
  constructor(
    private ajaxService: AjaxService,
    private modalController: ModalController
  ) { }

  radioSelect($event, item) {
    this.shownContent["rtoStatus"] = $event.detail.value
  }

  verifiOtp() {
    if(this.otp == this.shownContent["otp"]){
      this.showContent = true
    }else{
      this.showContent = false
    }
  }

  submit() {
    this.shownContent["rtoComment"] = this.textBox
    let url = ServerUrl.live + "/certificate/updatee";
    this.ajaxService.ajaxPostWithBody(url, this.shownContent)
      .subscribe(res => {
        console.log(res)
        if (res) {
          this.modalController.dismiss()
        } else {

        }
      })
  }

  ngOnInit() {
  }

}
