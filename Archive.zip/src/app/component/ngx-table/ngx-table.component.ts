import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DatatableComponent, ColumnMode } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-ngx-table',
  templateUrl: './ngx-table.component.html',
  styleUrls: ['./ngx-table.component.scss'],
})
export class NgxTableComponent implements OnInit {
  @ViewChild('myTable') table: DatatableComponent;
  @Output() selectedRowData = new EventEmitter();

  @Input() datalist;
  ColumnMode = ColumnMode
  temp=[];
  constructor() { }

ngOnChanges(){
  if(this.datalist){
    this.datalist = this.datalist
  }
}
onActivate(event){
  if(event.type == 'click') {
    console.log(event.row);
    this.selectedRowData.emit(event.row)
}
}
  ngOnInit() {
  }

}
