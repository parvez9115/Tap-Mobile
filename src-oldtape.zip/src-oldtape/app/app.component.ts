import { Component, OnInit } from '@angular/core';

import {  Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { CommonServices } from './services/common.service';
import { Storage } from '@ionic/storage';
import {TapestockService} from './services/tapestock.service';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  public selectedIndex = 0;
  data;
  public appPages = [
    {
      title: 'Dashboard',
      url: '/dashboard',
      icon: 'person'
    },
    {
      title: 'Logout',
      url: '/login',
      icon: 'log-out'
    }

  ];
  loginCreation: Object = {
    companyName: "Welcome"
  };

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private commonService: CommonServices,
    private storage: Storage,
    private datas:TapestockService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();

      this.commonService.loginMenuInfo.subscribe(res => {
        if (res) {
          this.selectedIndex = 0
          this.loginCreation={}
          this.loginCreation['name'] = res['name'];
          this.loginCreation["userId"] = res['userId'];
          this.loginCreation["roleName"] = res["role"]["roleName"]
          this.loginCreation["email"] = res['email'];
          this.data = res
          this.datas.changeMessage(this.data);
          this.datas.currentMessage.subscribe(message => this.data = message);
        } else {
          this.storage.get('loginRes').then((res) => {
            if (res) {
              res = JSON.parse(res)
              this.loginCreation={}
              this.loginCreation['name'] = res['name'];
              this.loginCreation["email"] = res['email'];
              this.loginCreation["roleName"] = res["role"]["roleName"]
              this.data = res
              this.datas.changeMessage(this.data);
              this.datas.currentMessage.subscribe(message => this.data = message);
            }
          });
        }

      });
    
      
    });
  }

  ngOnInit() {

  }
}
