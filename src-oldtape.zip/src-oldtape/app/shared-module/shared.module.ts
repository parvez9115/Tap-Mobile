import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SuperAdminComponent } from '../dashboard/super-admin/super-admin.component'
import { DealerComponent } from '../dashboard/dealer/dealer.component';
import { NgxTableComponent  } from '../component/ngx-table/ngx-table.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxTableRtoComponent } from '../component/ngx-table-rto/ngx-table-rto.component';

@NgModule({
  declarations: [
    SuperAdminComponent,
    DealerComponent,
    NgxTableComponent,
    NgxTableRtoComponent
  ],
  imports: [
    CommonModule,
    NgxDatatableModule
  ],
  exports:[
    SuperAdminComponent,
    DealerComponent,
    NgxTableComponent,
    NgxTableRtoComponent
  ]
})
export class SharedModule { }
