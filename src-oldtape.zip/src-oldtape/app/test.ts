export interface name {
    person: string,
    data : number,
    rollno? : number
}