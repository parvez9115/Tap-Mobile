import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { DatatableComponent, ColumnMode } from '@swimlane/ngx-datatable';
import { StatusComponent } from '../status/status.component';

@Component({
  selector: 'app-ngx-table',
  templateUrl: './ngx-table.component.html',
  styleUrls: ['./ngx-table.component.scss'],
})
export class NgxTableComponent implements OnInit {
  @ViewChild('myTable') table: DatatableComponent;
  @Output() selectedRowData = new EventEmitter();
  @Output() refresh = new EventEmitter();
  @Input() datalist;
  hide = false
  ColumnMode = ColumnMode
  temp=[];
  valid: boolean = false;
  data: any;
  constructor( private modalController: ModalController,  private router: Router,
    ) { }

ngOnChanges(){
  if(this.datalist){
   if( this.router.url.includes('reports')){
    this.hide = false
   }else{
    this.hide = true
   }
    this.datalist = this.datalist
    // this.ionViewWillEnter()
  }
}

// onPageChange(pageInfo: any): void {
//   alert( pageInfo.offset)
//   this.datalist.push({'cer':909})
//   // this.gridQuery.page.size = this.page.size;
//   // this.gridQuery.page.pageNumber = pageInfo.offset + 1;

// }

async openModel(data) {
  const modal = await this.modalController.create({
      component: StatusComponent,
      cssClass: 'custome_fleet',
      componentProps: {
        value: data
    }
  });
  modal.onDidDismiss().then(() => {
      this.valid = false
      // this.refresh.emit('true')
      // this.router.navigateByUrl('/dashboard')
  })
  return await modal.present();
}

onActivate(event,data){
  this.data = event.row
  if(event.type == 'click' && !this.valid) {
    console.log(event.row);
    this.selectedRowData.emit(event.row)
}
}

test(event,data){
this.valid = true
this.openModel( this.data )
// this.
}

ionViewWillEnter(){
  this.valid = false

}


  ngOnInit() {

  }

}
