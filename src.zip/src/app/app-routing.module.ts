import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { DealerComponent } from './dashboard/dealer/dealer.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'dashboard-count',
    loadChildren: () => import('./dashboard-count/dashboard-count.module').then( m => m.DashboardCountPageModule)
  },
  {
    path: 'dashbboard',
    loadChildren: () => import('./dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },
  {
    path: 'common-form/:method/:type/:data',
    loadChildren: () => import('./common-form/common-form.module').then( m => m.CommonFormPageModule)
  },
  {
    path: 'rto-dashboard',
    loadChildren: () => import('./rto-dashboard/rto-dashboard.module').then( m => m.RtoDashboardPageModule)
  },
  {
    path: 'qr-generation',
    loadChildren: () => import('./qr-generation/qr-generation.module').then( m => m.QrGenerationPageModule)
  },
  {
    path: 'excell-uploader',
    loadChildren: () => import('./excell-uploader/excell-uploader.module').then( m => m.ExcellUploaderPageModule)
  },{
    path: 'DealerComponent',
   loadChildren: () => import('./dashboard/dashboard.module').then(m=> m.DashboardPageModule)
  },
  {
    path: 'dealer-certification-list',
    loadChildren: () => import('./dealer-certification-list/dealer-certification-list.module').then( m => m.DealerCertificationListPageModule)
  },
 
  {
    path: 'reports',
    loadChildren: () => import('./reports/reports.module').then( m => m.ReportsPageModule)
  }
  // {
  //   path: 'test-pdf',
  //   loadChildren: () => import('./test-pdf/test-pdf.module').then( m => m.TestPDFPageModule)
  // }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
