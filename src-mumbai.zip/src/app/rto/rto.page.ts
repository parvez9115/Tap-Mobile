import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rto',
  templateUrl: './rto.page.html',
  styleUrls: ['./rto.page.scss'],
})
export class RtoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
