import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-rto',
  templateUrl: './add-rto.component.html',
  styleUrls: ['./add-rto.component.scss'],
})
export class AddRtoComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
