import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qr-pdf',
  templateUrl: './qr-pdf.component.html',
  styleUrls: ['./qr-pdf.component.scss'],
})
export class QrPdfComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
