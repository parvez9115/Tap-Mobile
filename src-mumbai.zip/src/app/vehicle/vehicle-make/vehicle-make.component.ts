import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-make',
  templateUrl: './vehicle-make.component.html',
  styleUrls: ['./vehicle-make.component.scss'],
})
export class VehicleMakeComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
