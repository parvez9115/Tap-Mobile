import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ServerUrl } from 'src/environments/environment';
import { AjaxService } from '../services/ajax.service';
import { AddProductComponent } from './add-product/add-product.component';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.page.html',
  styleUrls: ['./add-products.page.scss'],
})
export class AddProductsPage implements OnInit {

  constructor(private ajaxService: AjaxService,private modalController: ModalController) { }
  memberList;

  getDatas(){
    const url = ServerUrl.live + "/product/getAllProduct";
    this.ajaxService.ajaxGet(url).subscribe(res=>{
      console.log(res);
      this.memberList = res;
    });
  }
  selectedRowRecived(ev){
    this.openModel(ev)
  }
  async openModel(data) {
    const modal = await this.modalController.create({
        component: AddProductComponent,
        cssClass: 'custome_fleet',
        componentProps: {
          value: data
      }
    });
    modal.onDidDismiss().then(() => {
      //  this.reset('')
    })
    return await modal.present();
  }

  ngOnInit() {
    this.getDatas()
  
  }

}
